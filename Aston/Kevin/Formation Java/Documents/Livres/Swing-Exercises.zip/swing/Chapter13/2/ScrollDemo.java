/**
	ScrollDemo
*/
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;

public class ScrollDemo 
	extends JFrame
{
	public ScrollDemo() 
	{
		super("JScrollBar Demo");
		setSize(300,250);

		ImageIcon ii = new ImageIcon("earth.jpg");
		CustomScrollPane sp = new CustomScrollPane(new JLabel(ii));
		getContentPane().add(sp);

		WindowListener wndCloser = new WindowAdapter()
		{
			public void windowClosing(WindowEvent e) 
			{
				System.exit(0);
			}
		};
		addWindowListener(wndCloser);
		setVisible(true);
	}

	public static void main(String[] args) 
	{ 
		new ScrollDemo();
	}
}

class CustomScrollPane
	extends JPanel
{
	protected JScrollBar m_vertSB;
	protected JScrollBar m_horzSB;
	protected CustomViewport m_viewport;
	protected JComponent m_comp;

	public CustomScrollPane(JComponent comp)
	{
		setLayout(null);
		m_viewport = new CustomViewport();
		m_viewport.setLayout(null);
		add(m_viewport);
		m_comp = comp;
		m_viewport.add(m_comp);

		m_vertSB = new JScrollBar(JScrollBar.VERTICAL, 0, 0, 0, 0);
		m_vertSB.setUnitIncrement(5);
		add(m_vertSB);

		m_horzSB = new JScrollBar(JScrollBar.HORIZONTAL, 0, 0, 0, 0);
		m_horzSB.setUnitIncrement(5);
		add(m_horzSB);

		AdjustmentListener lst = new AdjustmentListener()
		{
			public void adjustmentValueChanged(AdjustmentEvent e)
			{
				m_viewport.doLayout();
			}
		};
		m_vertSB.addAdjustmentListener(lst);
		m_horzSB.addAdjustmentListener(lst);
	}

	public void doLayout()
	{
		Dimension d = getSize();
		Dimension d0 = m_comp.getPreferredSize();
		Dimension d1 = m_vertSB.getPreferredSize();
		Dimension d2 = m_horzSB.getPreferredSize();

		int w = Math.max(d.width - d1.width-1, 0);
		int h = Math.max(d.height - d2.height-1, 0);
		m_viewport.setBounds(0, 0, w, h);
		m_vertSB.setBounds(w+1, 0, d1.width, h);
		m_horzSB.setBounds(0, h+1, w, d2.height);

		int xs = Math.max(d0.width - w, 0);
		m_horzSB.setMaximum(xs);
		m_horzSB.setBlockIncrement(xs/5);
		m_horzSB.setEnabled(xs > 0);

		int ys = Math.max(d0.height - h, 0);
		m_vertSB.setMaximum(ys);
		m_vertSB.setBlockIncrement(ys/5);
		m_vertSB.setEnabled(ys > 0);

                m_horzSB.setVisibleAmount(m_horzSB.getBlockIncrement());
                m_vertSB.setVisibleAmount(m_vertSB.getBlockIncrement());
	}

	public Dimension getPreferredSize()
	{
		Dimension d0 = m_comp.getPreferredSize();
		Dimension d1 = m_vertSB.getPreferredSize();
		Dimension d2 = m_horzSB.getPreferredSize();
		Dimension d = new Dimension(d0.width+d1.width, 
			d0.height+d2.height);
		return d;
	}

	class CustomViewport
		extends JPanel
	{
		public void doLayout()
		{
			Dimension d0 = m_comp.getPreferredSize();
			int x = m_horzSB.getValue();
			int y = m_vertSB.getValue();
			m_comp.setBounds(-x, -y, d0.width, d0.height);
		}
	}
}
