/**
	JProgressBar Demo
*/
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.event.*;

public class JProgressBarDemo 
	extends JFrame
{

        protected int m_min = 0;
        protected int m_max = 100;
        protected int m_counter = 0;
        protected JProgressBar jpb;

	public JProgressBarDemo() 
	{
		super("JProgressBar Demo");
		setSize(300,50);

                UIManager.put("ProgressBar.selectionBackground", Color.black);
                UIManager.put("ProgressBar.selectionForeground", Color.white);
                UIManager.put("ProgressBar.foreground", new Color(8,32,128));

                jpb = new JProgressBar();
                jpb.setMinimum(m_min);
                jpb.setMaximum(m_max);
                jpb.setStringPainted(true);

                JButton start = new JButton("Start");
                start.addActionListener(new ActionListener() {
                  public void actionPerformed(ActionEvent e) {
                    Thread runner = new Thread() {
                      public void run() {
                        m_counter = m_min;
                        while (m_counter <= m_max) {
                          Runnable runme = new Runnable() {
                            public void run() {
                              jpb.setValue(m_counter);
                            }
                          };
                          SwingUtilities.invokeLater(runme);
                          m_counter++;
                          try { 
                            Thread.sleep(100); 
                          } 
                          catch (Exception ex) {}
                        }
                      }
                    };
                    runner.start();
                  }
                });
        
		getContentPane().add(jpb, BorderLayout.CENTER);
                getContentPane().add(start, BorderLayout.WEST);

		WindowListener wndCloser = new WindowAdapter()
		{
			public void windowClosing(WindowEvent e) 
			{
				System.exit(0);
			}
		};
		addWindowListener(wndCloser);
		setVisible(true);
	}

	public static void main(String[] args) 
	{ 
		new JProgressBarDemo();
	}
}