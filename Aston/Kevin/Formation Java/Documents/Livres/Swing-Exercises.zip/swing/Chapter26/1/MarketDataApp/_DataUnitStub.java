/*
 * File: ./MARKETDATAAPP/_DATAUNITSTUB.JAVA
 * From: MARKETDATA.IDL
 * Date: Tue Feb 09 11:31:12 1999
 *   By: idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package MarketDataApp;
public class _DataUnitStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements MarketDataApp.DataUnit {

    public _DataUnitStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:MarketDataApp/DataUnit:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::MarketDataApp::DataUnit::getSymbol
    public String getSymbol()
 {
           org.omg.CORBA.Request r = _request("getSymbol");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
           r.invoke();
           String __result;
           __result = r.return_value().extract_string();
           return __result;
   }
    //	    Implementation of ::MarketDataApp::DataUnit::getName
    public String getName()
 {
           org.omg.CORBA.Request r = _request("getName");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
           r.invoke();
           String __result;
           __result = r.return_value().extract_string();
           return __result;
   }
    //	    Implementation of ::MarketDataApp::DataUnit::getLast
    public double getLast()
 {
           org.omg.CORBA.Request r = _request("getLast");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_double));
           r.invoke();
           double __result;
           __result = r.return_value().extract_double();
           return __result;
   }
    //	    Implementation of ::MarketDataApp::DataUnit::getOpen
    public double getOpen()
 {
           org.omg.CORBA.Request r = _request("getOpen");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_double));
           r.invoke();
           double __result;
           __result = r.return_value().extract_double();
           return __result;
   }
    //	    Implementation of ::MarketDataApp::DataUnit::getChange
    public double getChange()
 {
           org.omg.CORBA.Request r = _request("getChange");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_double));
           r.invoke();
           double __result;
           __result = r.return_value().extract_double();
           return __result;
   }
    //	    Implementation of ::MarketDataApp::DataUnit::getChangePr
    public double getChangePr()
 {
           org.omg.CORBA.Request r = _request("getChangePr");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_double));
           r.invoke();
           double __result;
           __result = r.return_value().extract_double();
           return __result;
   }
    //	    Implementation of ::MarketDataApp::DataUnit::getVolume
    public int getVolume()
 {
           org.omg.CORBA.Request r = _request("getVolume");
           r.set_return_type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_long));
           r.invoke();
           int __result;
           __result = r.return_value().extract_long();
           return __result;
   }

};
