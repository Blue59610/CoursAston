/*
 * File: ./MARKETDATAAPP/DATAUNIT.JAVA
 * From: MARKETDATA.IDL
 * Date: Tue Feb 09 11:31:12 1999
 *   By: idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package MarketDataApp;
public interface DataUnit
    extends org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity {
    String getSymbol()
;
    String getName()
;
    double getLast()
;
    double getOpen()
;
    double getChange()
;
    double getChangePr()
;
    int getVolume()
;
}
