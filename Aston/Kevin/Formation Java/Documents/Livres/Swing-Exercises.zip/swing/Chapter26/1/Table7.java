/**
	Table7
*/
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import java.text.*;
//import java.sql.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.table.*;

import dl.*;	// NEW
import MarketDataApp.*;

// NEW
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;

public class Table7 
	extends    JFrame 
{

	protected JTable m_table;
	protected StockTableData m_data;
	protected JLabel m_title;

// NEW
	private String m_name = "CORBA";
	private String m_password = "Swing";
	protected MarketData m_server = null;	// Remote server ref.

	public Table7()
	{
		super("Swing Table [CORBA]");
		setSize(770, 300);
		getContentPane().setLayout(new BorderLayout());

		m_data = new StockTableData();

		m_title = new JLabel(m_data.getTitle(), 
			new ImageIcon("money.gif"), SwingConstants.LEFT);
		m_title.setFont(new Font("TimesRoman",Font.BOLD,24));
		m_title.setForeground(Color.black);
		getContentPane().add(m_title, BorderLayout.NORTH);

		m_table = new JTable();
		m_table.setAutoCreateColumnsFromModel(false);
		m_table.setModel(m_data); 
		
		for (int k = 0; k < StockTableData.m_columns.length; k++)
		{
			DefaultTableCellRenderer renderer = new 
				ColoredTableCellRenderer();
			renderer.setHorizontalAlignment(
				StockTableData.m_columns[k].m_alignment);
			TableColumn column = new TableColumn(k, 
				StockTableData.m_columns[k].m_width, renderer, null);
			m_table.addColumn(column);   
		}

		JTableHeader header = m_table.getTableHeader();
		header.setUpdateTableInRealTime(false);
		header.addMouseListener(m_data.new ColumnListener(m_table));

		m_table.getColumnModel().addColumnModelListener(
			m_data.new ColumnMovementListener());

		JScrollPane ps = new JScrollPane();
		ps.getViewport().add(m_table);
		getContentPane().add(ps, BorderLayout.CENTER);

		JMenuBar menuBar = createMenuBar();
		setJMenuBar(menuBar);

		WindowListener wndCloser = new WindowAdapter()
		{
			public void windowOpened(WindowEvent e)	// NEW
			{
				LoginDialog dlg = new LoginDialog(Table7.this);
				dlg.show();
				if (!dlg.getOkFlag())
					System.exit(0);

				// Connect to the server
				try
				{
					// create and initialize the ORB
					String[] args = new String[] 
						{ "-ORBInitialPort", "1250", 
						"ORBInitialHost", "localhost" };
					ORB orb = ORB.init(args, null); 
					
					// get the root naming context
					org.omg.CORBA.Object objRef = 
						orb.resolve_initial_references("NameService");
					NamingContext ncRef = NamingContextHelper.narrow(objRef);
					
					// resolve the Object Reference in Naming
					NameComponent nc = new NameComponent("MarketData", "");
					NameComponent path[] = {nc};
					m_server = MarketDataHelper.narrow(ncRef.resolve(path));
				} 
				catch (Exception ex) 
				{	    
					ex.printStackTrace(System.out);	
					System.exit(0);
				}

				retrieveData();
			}

			public void windowClosing(WindowEvent e) 
			{
				System.exit(0);
			}
		};
		addWindowListener(wndCloser);
		
		setVisible(true);
	}

	protected JMenuBar createMenuBar()
	{
		JMenuBar menuBar = new JMenuBar();
		
		JMenu mFile = new JMenu("File");
		JMenuItem mData = new JMenuItem("Retrieve Data...");
		ActionListener lstData = new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent e)
			{ 
				retrieveData(); 
			}
		};
		mData.addActionListener(lstData);
		mFile.add(mData);
		mFile.addSeparator();

		JMenuItem mExit = new JMenuItem("Exit");
		ActionListener lstExit = new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent e)
			{
				System.exit(0);
			}
		};
		mExit.addActionListener(lstExit);
		mFile.add(mExit);
		menuBar.add(mFile);

		JMenu mView = new JMenu("View");
		TableColumnModel model = m_table.getColumnModel();
		for (int k = 0; k < StockTableData.m_columns.length; k++)
		{
			JCheckBoxMenuItem item = new JCheckBoxMenuItem(
				StockTableData.m_columns[k].m_title);
			item.setSelected(true);
			TableColumn column = model.getColumn(k);
			item.addActionListener(new ColumnKeeper(column, 
				StockTableData.m_columns[k]));
			mView.add(item);
		}
		menuBar.add(mView);

		return menuBar;
	}

	public void retrieveData()
	{
		SimpleDateFormat frm = new SimpleDateFormat("MM/dd/yyyy");
		String currentDate = (m_data.m_date == null ? "7/22/1998" :		// NEW
			frm.format(m_data.m_date));
		String result = (String)JOptionPane.showInputDialog(this, 
			"Please enter date in form mm/dd/yyyy:", "Input", 
			JOptionPane.INFORMATION_MESSAGE, null, null, 
			currentDate);
		if (result==null)
			return;

		java.util.Date  date = null;
		try 
		{ 
			date = frm.parse(result); 
		}
		catch (java.text.ParseException ex) 
		{ 
			date = null; 
		}
		
		if (date == null)
		{
			JOptionPane.showMessageDialog(this, 
				result+" is not a valid date",
				"Warning", JOptionPane.WARNING_MESSAGE);
			return;
		}

		setCursor( Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR) );
		switch (m_data.retrieveData(date, m_name, m_password, m_server))
		{
		case 0:	// Ok with data
			m_title.setText(m_data.getTitle());
			m_table.tableChanged(new TableModelEvent(m_data)); 
			m_table.repaint();
			break;
		case 1: // No data
			JOptionPane.showMessageDialog(this, "No data found for "+result,
				"Warning", JOptionPane.WARNING_MESSAGE);
			break;
		case -1: // Error
			JOptionPane.showMessageDialog(this, "Error retrieving data",
				"Warning", JOptionPane.WARNING_MESSAGE);
			break;
		}
		setCursor( Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR) );

	}

	class ColumnKeeper 
		implements ActionListener
	{
		protected TableColumn m_column;
		protected ColumnData  m_colData;

		public ColumnKeeper(TableColumn column, ColumnData  colData)
		{
			m_column = column;
			m_colData = colData;
		}

		public void actionPerformed(ActionEvent e)
		{
			JCheckBoxMenuItem item = (JCheckBoxMenuItem)e.getSource();
			TableColumnModel model = m_table.getColumnModel();
			if (item.isSelected())
			{
				m_colData.m_index = model.getColumnCount();
				model.addColumn(m_column);
			}
			else
			{
				int oldIndex = m_colData.m_index;
				for (int k=0; k<StockTableData.m_columns.length; k++)
					if (StockTableData.m_columns[k].m_index > oldIndex)
						StockTableData.m_columns[k].m_index--;
				m_colData.m_index = -1;
				model.removeColumn(m_column);
			}
			m_table.tableChanged(new TableModelEvent(m_data)); 
			m_table.repaint();
		}
	}

	// NEW
	class LoginDialog
		extends JDialog
	{
		protected JTextField m_nameTxt;
		protected JPasswordField m_passTxt;
		protected boolean m_okFlag = false;

		public LoginDialog(Frame owner)
		{
			super(owner, "Login", true);
			JPanel p = new JPanel(new DialogLayout2());
			p.add(new JLabel("Name:"));
			m_nameTxt = new JTextField(m_name, 20);
			p.add(m_nameTxt);
			p.add(new JLabel("Password:"));
			m_passTxt = new JPasswordField(m_password);
			p.add(m_passTxt);
			p.add(new DialogSeparator());

			JButton btOK = new JButton("OK");
			ActionListener lst = new ActionListener() 
			{ 
				public void actionPerformed(ActionEvent e)
				{
					m_name = m_nameTxt.getText();
					m_password = new String(m_passTxt.getPassword());
					m_okFlag = true;
					dispose();
				}
			};
			btOK.addActionListener(lst);
			p.add(btOK);

			JButton btCancel = new JButton("Cancel");
			lst = new ActionListener() 
			{ 
				public void actionPerformed(ActionEvent e)
				{
					dispose();
				}
			};
			btCancel.addActionListener(lst);
			p.add(btCancel);

			p.setBorder(new EmptyBorder(10, 10, 10, 10));
			getContentPane().add(p);
			pack();
			setResizable(false);
			Dimension d1 = getSize();
			Dimension d2 = owner.getSize();
			int x = Math.max((d2.width-d1.width)/2, 0);
			int y = Math.max((d2.height-d1.height)/2, 0);
			setBounds(x, y, d1.width, d1.height);
		}

		public boolean getOkFlag()
		{
			return m_okFlag;
		}
	}

	public static void main(String argv[]) 
	{
		new Table7();
	}
}

class ColoredTableCellRenderer 
	extends DefaultTableCellRenderer
{
	public void setValue(java.lang.Object value) // NEW
	{
		if (value==null)
			return;
		if (value instanceof ColorData) 
		{
			ColorData cvalue = (ColorData)value;
			setForeground(cvalue.m_color);
			setText(cvalue.m_data.toString());
        }
		else if (value instanceof IconData) 
		{
			IconData ivalue = (IconData)value;
			setIcon(ivalue.m_icon);
			setText(ivalue.m_data.toString());
        }
		else
			super.setValue(value);
	}
}

class Fraction
{
	public int m_whole;
	public int m_nom;
	public int m_den;

	public Fraction(double value)
	{
		int sign = value <0 ? -1 : 1;
		value = Math.abs(value);
		m_whole = (int)value;
		m_den = 32;
		m_nom = (int)((value-m_whole)*m_den);
		while (m_nom!=0 && m_nom%2==0)
		{
			m_nom /= 2;
			m_den /= 2;
		}
		if (m_whole==0)
			m_nom *= sign;
		else
			m_whole *= sign;
	}

	public double doubleValue()
	{
		return (double)m_whole + (double)m_nom/m_den;
	}

	public String toString()
	{
		if (m_nom==0)
			return ""+m_whole;
		else if (m_whole==0)
			return ""+m_nom+"/"+m_den;
		else
			return ""+m_whole+" "+m_nom+"/"+m_den;
	}
}

class SmartLong
{
	protected static NumberFormat FORMAT;
	static
	{
		FORMAT = NumberFormat.getInstance();
		FORMAT.setGroupingUsed(true);
	}

	public long m_value;

	public SmartLong(long value)
	{
		m_value = value;
	}

	public long longValue()
	{
		return m_value;
	}

	public String toString()
	{
		return FORMAT.format(m_value);
	}
}

class ColorData
{
	public Color  m_color;
	public java.lang.Object m_data;
	public static Color GREEN = new Color(0, 128, 0);
	public static Color RED = Color.red;
	
	public ColorData(Color color, java.lang.Object data)
	{
		m_color = color;
		m_data  = data;
	}
	
	public ColorData(Double data)
	{
		m_color = data.doubleValue() >= 0 ? GREEN : RED;
		m_data  = data;
	}
	
	public ColorData(Fraction data)	
	{
		m_color = data.doubleValue() >= 0 ? GREEN : RED;
		m_data  = data;
	}
	
	public String toString()
	{
		return m_data.toString();
	}
}

class IconData
{
	public ImageIcon  m_icon;
	public java.lang.Object m_data;
	
	public IconData(ImageIcon icon, java.lang.Object data)
	{
		m_icon = icon;
		m_data = data;
	}
	
	public String toString()
	{
		return m_data.toString();
	}
}

class StockData
{
	public static ImageIcon ICON_UP = new ImageIcon("ArrUp.gif");
	public static ImageIcon ICON_DOWN = new ImageIcon("ArrDown.gif");
	public static ImageIcon ICON_BLANK = new ImageIcon("blank.gif");

	public IconData  m_symbol;	
	public String  m_name;
	public Fraction  m_last;
	public Fraction  m_open;
	public ColorData  m_change;
	public ColorData  m_changePr;
	public SmartLong  m_volume;

	public StockData(String symbol, String name, double last, 
		double open, double change, double changePr, long volume)
	{
		m_symbol = new IconData(getIcon(change), symbol);
		m_name = name;
		m_last = new Fraction(last);
		m_open = new Fraction(open);
		m_change = new ColorData(new Fraction(change));
		m_changePr = new ColorData(new Double(changePr));
		m_volume = new SmartLong(volume);
	}

// NEW
	public StockData(DataUnit unit)
	{
		this(unit.getSymbol(), unit.getName(), unit.getLast(), 
			unit.getOpen(), unit.getChange(), unit.getChangePr(), 
			unit.getVolume());
	}

	public static ImageIcon getIcon(double change)
	{
		return (change>0 ? ICON_UP : (change<0 ? ICON_DOWN : ICON_BLANK));
	}
}

class ColumnData
{
	public String  m_title;
	public int     m_width;
	public int     m_alignment;

	private static int counter = 0;
	public  int    m_index;

	public ColumnData(String title, int width, int alignment) 
	{
		m_title = title;
		m_width = width;
		m_alignment = alignment;
		m_index = counter++;
	}
}

class StockTableData 
	extends    AbstractTableModel 
{
	static final public ColumnData m_columns[] = {
		new ColumnData( "Symbol", 100, JLabel.LEFT ),
		new ColumnData( "Name", 150, JLabel.LEFT ),
		new ColumnData( "Last", 100, JLabel.RIGHT ),
		new ColumnData( "Open", 100, JLabel.RIGHT ),
		new ColumnData( "Change", 100, JLabel.RIGHT ),
		new ColumnData( "Change %", 100, JLabel.RIGHT ),
		new ColumnData( "Volume", 100, JLabel.RIGHT )
	};

	protected SimpleDateFormat m_frm;
	protected Vector m_vector;
	protected java.util.Date   m_date;
	protected int m_columnsCount = m_columns.length;

	protected int     m_sortCol = 0;
	protected boolean m_sortAsc = true;

	public StockTableData()
	{
		m_frm = new SimpleDateFormat("MM/dd/yyyy");
		m_vector = new Vector();
		//setDefaultData();		No more in use	NEW
	}

	public int getRowCount() 
	{
		 return m_vector==null ? 0 : m_vector.size(); 
	}

	public int getColumnCount() 
	{ 
		return m_columnsCount;
	} 

	public int getOriginalIndex(int column) 
	{
		for (int k=0; k<m_columns.length; k++)
			if (column == m_columns[k].m_index)
				return k;
		return -1;	// We shouldn't be here...
	}

	public String getColumnName(int column) 
	{
		int index = getOriginalIndex(column);
		if (index < 0)
			return "";	// We shouldn't be here...
		String str = m_columns[index].m_title;
		if (index==m_sortCol)
			str += m_sortAsc ? " �" : " �";
		return str;
	}
 
	public boolean isCellEditable(int nRow, int nCol)
	{
		return false;
	}

	public java.lang.Object getValueAt(int nRow, int nCol) 
	{
		if (nRow < 0 || nRow>=getRowCount())
			return "";
		StockData row = (StockData)m_vector.elementAt(nRow);
		switch (nCol)
		{
		case 0:
			return row.m_symbol;
		case 1:
			return row.m_name;
		case 2:
			return row.m_last;
		case 3:
			return row.m_open;
		case 4:
			return row.m_change;
		case 5:
			return row.m_changePr;
		case 6:
			return row.m_volume;
		}
		return "";
	}

	public String getTitle()
	{
		if (m_date==null)
			return "Stock Quotes";
		return "Stock Quotes at "+m_frm.format(m_date);
	}

	class ColumnMovementListener
		implements TableColumnModelListener
	{
		public void columnMoved(TableColumnModelEvent e)
		{
			int iFrom = getOriginalIndex(e.getFromIndex());
			int iTo   = getOriginalIndex(e.getToIndex());

			int tmp = m_columns[iFrom].m_index;
			m_columns[iFrom].m_index = m_columns[iTo].m_index;
			m_columns[iTo].m_index = tmp;
		}

		public void columnAdded(TableColumnModelEvent e)
		{
			m_columnsCount++;
		}

		public void columnMarginChanged(ChangeEvent e) {}

		public void columnRemoved(TableColumnModelEvent e)
		{
			m_columnsCount--;
		}

		public void columnSelectionChanged(ListSelectionEvent e) {}
	}

	public void columnMoved(TableColumnModelEvent e)
	{
		int iFrom = getOriginalIndex(e.getFromIndex());
		int iTo   = getOriginalIndex(e.getToIndex());

		int tmp = m_columns[iFrom].m_index;
		m_columns[iFrom].m_index = m_columns[iTo].m_index;
		m_columns[iTo].m_index = tmp;
	}

	class ColumnListener 
		extends MouseAdapter
	{
		protected JTable m_table;

		public ColumnListener(JTable table)
		{
			m_table = table;
		}

		public void mouseClicked(MouseEvent e)
		{
			TableColumnModel colModel = m_table.getColumnModel();
			int column = colModel.getColumnIndexAtX(e.getX());
			if (column < 0)
				return;
			int newSortCol = getOriginalIndex(column);
			if (newSortCol < 0)
				return;

			int oldSortCol = m_sortCol;
			if (m_sortCol==newSortCol)
				m_sortAsc = !m_sortAsc;
			else
				m_sortCol = newSortCol;

			for (int k=0; k<getColumnCount(); k++)
				colModel.getColumn(k).setHeaderValue(getColumnName(k));
			m_table.getTableHeader().repaint();  

			Collections.sort(m_vector, new StockComparator(m_sortCol, m_sortAsc));
			m_table.tableChanged(
				new TableModelEvent(StockTableData.this)); 
			m_table.repaint();  
		}
	}

// NEW - redefined
	public int retrieveData(java.util.Date date, String name, 
		String password, MarketData server)
	{
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		int month = calendar.get(Calendar.MONTH)+1;
		int day = calendar.get(Calendar.DAY_OF_MONTH);
		int year = calendar.get(Calendar.YEAR);

		try
		{
			DataUnit unit = server.getFirstData(name, password, 
				year, month, day);

			boolean hasData = false;
			while (unit != null) 
			{
				if (!hasData)
				{
					m_vector.removeAllElements();
					hasData = true;
				}
				m_vector.addElement(new StockData(unit));
				unit = server.getNextData();
			}

			if (!hasData)	// We've got nothing
				return 1;
		}
		catch (Exception e)
		{
			e.printStackTrace();
			System.err.println("Load data error: "+e.getMessage());
			return -1;
		}

		m_date = date;
		Collections.sort(m_vector, new 
			StockComparator(m_sortCol, m_sortAsc));

		return 0;
	}

}

class StockComparator 
	implements Comparator
{
	protected int     m_sortCol;
	protected boolean m_sortAsc;

	public StockComparator(int sortCol, boolean sortAsc)
	{
		m_sortCol = sortCol;
		m_sortAsc = sortAsc;
	}

	public int compare(java.lang.Object o1, java.lang.Object o2)
	{
		if (!(o1 instanceof StockData) || !(o2 instanceof StockData))
			return 0;
		StockData s1 = (StockData)o1;
		StockData s2 = (StockData)o2;
		int result = 0;
		double d1, d2;
		switch (m_sortCol)
		{
		case 0:	// symbol
			String str1 = (String)s1.m_symbol.m_data;
			String str2 = (String)s2.m_symbol.m_data;
			result = str1.compareTo(str2);
			break;
		case 1:	// name
			result = s1.m_name.compareTo(s2.m_name);
			break;
		case 2:	// last
			d1 = s1.m_last.doubleValue();
			d2 = s2.m_last.doubleValue();
			result = d1<d2 ? -1 : (d1>d2 ? 1 : 0);
			break;
		case 3:	// open
			d1 = s1.m_open.doubleValue();
			d2 = s2.m_open.doubleValue();
			result = d1<d2 ? -1 : (d1>d2 ? 1 : 0);
			break;
		case 4:	// change
			d1 = ((Fraction)s1.m_change.m_data).doubleValue();
			d2 = ((Fraction)s2.m_change.m_data).doubleValue();
			result = d1<d2 ? -1 : (d1>d2 ? 1 : 0);
			break;
		case 5:	// change %
			d1 = ((Double)s1.m_changePr.m_data).doubleValue();
			d2 = ((Double)s2.m_changePr.m_data).doubleValue();
			result = d1<d2 ? -1 : (d1>d2 ? 1 : 0);
			break;
		case 6:	// volume
			long l1 = s1.m_volume.longValue();
			long l2 = s2.m_volume.longValue();
			result = l1<l2 ? -1 : (l1>l2 ? 1 : 0);
			break;
		}

		if (!m_sortAsc)
			result = -result;
		return result;
	}

	public boolean equals(java.lang.Object obj)
	{
		if (obj instanceof StockComparator)
		{
			StockComparator compObj = (StockComparator)obj;
			return (compObj.m_sortCol==m_sortCol) && 
				(compObj.m_sortAsc==m_sortAsc);
		}
		return false;
	}
}
