/*
 * File: ./MARKETDATAAPP/LOGINEXCEPTION.JAVA
 * From: MARKETDATA.IDL
 * Date: Tue Feb 09 11:31:12 1999
 *   By: idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package MarketDataApp;
public final class LoginException
	extends org.omg.CORBA.UserException implements org.omg.CORBA.portable.IDLEntity {
    //	constructor
    public LoginException() {
	super();
    }
}
