/*
 * File: ./MARKETDATAAPP/DATAUNITHOLDER.JAVA
 * From: MARKETDATA.IDL
 * Date: Tue Feb 09 11:31:12 1999
 *   By: idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package MarketDataApp;
public final class DataUnitHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public MarketDataApp.DataUnit value;
    //	constructors 
    public DataUnitHolder() {
	this(null);
    }
    public DataUnitHolder(MarketDataApp.DataUnit __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        MarketDataApp.DataUnitHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = MarketDataApp.DataUnitHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return MarketDataApp.DataUnitHelper.type();
    }
}
