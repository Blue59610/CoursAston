/*
 * File: ./MARKETDATAAPP/MARKETDATAHOLDER.JAVA
 * From: MARKETDATA.IDL
 * Date: Tue Feb 09 11:31:12 1999
 *   By: idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package MarketDataApp;
public final class MarketDataHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public MarketDataApp.MarketData value;
    //	constructors 
    public MarketDataHolder() {
	this(null);
    }
    public MarketDataHolder(MarketDataApp.MarketData __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        MarketDataApp.MarketDataHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = MarketDataApp.MarketDataHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return MarketDataApp.MarketDataHelper.type();
    }
}
