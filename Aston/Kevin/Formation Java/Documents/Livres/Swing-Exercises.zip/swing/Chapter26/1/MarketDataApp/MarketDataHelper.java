/*
 * File: ./MARKETDATAAPP/MARKETDATAHELPER.JAVA
 * From: MARKETDATA.IDL
 * Date: Tue Feb 09 11:31:12 1999
 *   By: idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package MarketDataApp;
public class MarketDataHelper {
     // It is useless to have instances of this class
     private MarketDataHelper() { }

    public static void write(org.omg.CORBA.portable.OutputStream out, MarketDataApp.MarketData that) {
        out.write_Object(that);
    }
    public static MarketDataApp.MarketData read(org.omg.CORBA.portable.InputStream in) {
        return MarketDataApp.MarketDataHelper.narrow(in.read_Object());
    }
   public static MarketDataApp.MarketData extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.create_input_stream();
     return read(in);
   }
   public static void insert(org.omg.CORBA.Any a, MarketDataApp.MarketData that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     write(out, that);
     a.read_value(out.create_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   synchronized public static org.omg.CORBA.TypeCode type() {
          if (_tc == null)
             _tc = org.omg.CORBA.ORB.init().create_interface_tc(id(), "MarketData");
      return _tc;
   }
   public static String id() {
       return "IDL:MarketDataApp/MarketData:1.0";
   }
   public static MarketDataApp.MarketData narrow(org.omg.CORBA.Object that)
	    throws org.omg.CORBA.BAD_PARAM {
        if (that == null)
            return null;
        if (that instanceof MarketDataApp.MarketData)
            return (MarketDataApp.MarketData) that;
	if (!that._is_a(id())) {
	    throw new org.omg.CORBA.BAD_PARAM();
	}
        org.omg.CORBA.portable.Delegate dup = ((org.omg.CORBA.portable.ObjectImpl)that)._get_delegate();
        MarketDataApp.MarketData result = new MarketDataApp._MarketDataStub(dup);
        return result;
   }
}
