/*
 * DataUnitImpl
 */

package MarketDataApp;

import java.sql.*;

public class DataUnitImpl
	extends _DataUnitImplBase
{
	protected String  m_symbol;
	protected String  m_name;
	protected double  m_last;
	protected double  m_open;
	protected double  m_change;
	protected double  m_changePr;
	protected long    m_volume;

	public DataUnitImpl(ResultSet results)
		throws SQLException
	{
		m_symbol = results.getString(1);
		m_name = results.getString(2);
		m_last = results.getDouble(3);
		m_open = results.getDouble(4);
		m_change = results.getDouble(5);
		m_changePr = results.getDouble(6);
		m_volume = results.getLong(7);
	}

	public String getSymbol()	{ return m_symbol; }

	public String getName()		{ return m_name; }

	public double getLast()		{ return m_last; }

	public double getOpen()		{ return m_open; }

	public double getChange()	{ return m_change; }

	public double getChangePr()	{ return m_changePr; }

	public int getVolume()		{ return (int)m_volume; }
}
