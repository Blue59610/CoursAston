/*
 * File: ./MARKETDATAAPP/_DATAUNITIMPLBASE.JAVA
 * From: MARKETDATA.IDL
 * Date: Tue Feb 09 11:31:12 1999
 *   By: idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package MarketDataApp;
public abstract class _DataUnitImplBase extends org.omg.CORBA.DynamicImplementation implements MarketDataApp.DataUnit {
    // Constructor
    public _DataUnitImplBase() {
         super();
    }
    // Type strings for this class and its superclases
    private static final String _type_ids[] = {
        "IDL:MarketDataApp/DataUnit:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    private static java.util.Dictionary _methods = new java.util.Hashtable();
    static {
      _methods.put("getSymbol", new java.lang.Integer(0));
      _methods.put("getName", new java.lang.Integer(1));
      _methods.put("getLast", new java.lang.Integer(2));
      _methods.put("getOpen", new java.lang.Integer(3));
      _methods.put("getChange", new java.lang.Integer(4));
      _methods.put("getChangePr", new java.lang.Integer(5));
      _methods.put("getVolume", new java.lang.Integer(6));
     }
    // DSI Dispatch call
    public void invoke(org.omg.CORBA.ServerRequest r) {
       switch (((java.lang.Integer) _methods.get(r.op_name())).intValue()) {
           case 0: // MarketDataApp.DataUnit.getSymbol
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
              String ___result;
                            ___result = this.getSymbol();
              org.omg.CORBA.Any __result = _orb().create_any();
              __result.insert_string(___result);
              r.result(__result);
              }
              break;
           case 1: // MarketDataApp.DataUnit.getName
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
              String ___result;
                            ___result = this.getName();
              org.omg.CORBA.Any __result = _orb().create_any();
              __result.insert_string(___result);
              r.result(__result);
              }
              break;
           case 2: // MarketDataApp.DataUnit.getLast
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
              double ___result;
                            ___result = this.getLast();
              org.omg.CORBA.Any __result = _orb().create_any();
              __result.insert_double(___result);
              r.result(__result);
              }
              break;
           case 3: // MarketDataApp.DataUnit.getOpen
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
              double ___result;
                            ___result = this.getOpen();
              org.omg.CORBA.Any __result = _orb().create_any();
              __result.insert_double(___result);
              r.result(__result);
              }
              break;
           case 4: // MarketDataApp.DataUnit.getChange
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
              double ___result;
                            ___result = this.getChange();
              org.omg.CORBA.Any __result = _orb().create_any();
              __result.insert_double(___result);
              r.result(__result);
              }
              break;
           case 5: // MarketDataApp.DataUnit.getChangePr
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
              double ___result;
                            ___result = this.getChangePr();
              org.omg.CORBA.Any __result = _orb().create_any();
              __result.insert_double(___result);
              r.result(__result);
              }
              break;
           case 6: // MarketDataApp.DataUnit.getVolume
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
              int ___result;
                            ___result = this.getVolume();
              org.omg.CORBA.Any __result = _orb().create_any();
              __result.insert_long(___result);
              r.result(__result);
              }
              break;
            default:
              throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
       }
 }
}
