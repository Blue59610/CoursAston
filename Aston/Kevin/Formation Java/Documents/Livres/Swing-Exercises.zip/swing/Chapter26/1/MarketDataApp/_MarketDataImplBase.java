/*
 * File: ./MARKETDATAAPP/_MARKETDATAIMPLBASE.JAVA
 * From: MARKETDATA.IDL
 * Date: Tue Feb 09 11:31:12 1999
 *   By: idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package MarketDataApp;
public abstract class _MarketDataImplBase extends org.omg.CORBA.DynamicImplementation implements MarketDataApp.MarketData {
    // Constructor
    public _MarketDataImplBase() {
         super();
    }
    // Type strings for this class and its superclases
    private static final String _type_ids[] = {
        "IDL:MarketDataApp/MarketData:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    private static java.util.Dictionary _methods = new java.util.Hashtable();
    static {
      _methods.put("getFirstData", new java.lang.Integer(0));
      _methods.put("getNextData", new java.lang.Integer(1));
     }
    // DSI Dispatch call
    public void invoke(org.omg.CORBA.ServerRequest r) {
       switch (((java.lang.Integer) _methods.get(r.op_name())).intValue()) {
           case 0: // MarketDataApp.MarketData.getFirstData
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              org.omg.CORBA.Any _name = _orb().create_any();
              _name.type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
              _list.add_value("name", _name, org.omg.CORBA.ARG_IN.value);
              org.omg.CORBA.Any _password = _orb().create_any();
              _password.type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_string));
              _list.add_value("password", _password, org.omg.CORBA.ARG_IN.value);
              org.omg.CORBA.Any _year = _orb().create_any();
              _year.type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_long));
              _list.add_value("year", _year, org.omg.CORBA.ARG_IN.value);
              org.omg.CORBA.Any _month = _orb().create_any();
              _month.type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_long));
              _list.add_value("month", _month, org.omg.CORBA.ARG_IN.value);
              org.omg.CORBA.Any _day = _orb().create_any();
              _day.type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_long));
              _list.add_value("day", _day, org.omg.CORBA.ARG_IN.value);
              r.params(_list);
              String name;
              name = _name.extract_string();
              String password;
              password = _password.extract_string();
              int year;
              year = _year.extract_long();
              int month;
              month = _month.extract_long();
              int day;
              day = _day.extract_long();
              MarketDataApp.DataUnit ___result;
              try {
                            ___result = this.getFirstData(name, password, year, month, day);
              }
              catch (MarketDataApp.LoginException e0) {
                            org.omg.CORBA.Any _except = _orb().create_any();
                            MarketDataApp.LoginExceptionHelper.insert(_except, e0);
                            r.except(_except);
                            return;
              }
              catch (MarketDataApp.CorbaSqlException e1) {
                            org.omg.CORBA.Any _except = _orb().create_any();
                            MarketDataApp.CorbaSqlExceptionHelper.insert(_except, e1);
                            r.except(_except);
                            return;
              }
              org.omg.CORBA.Any __result = _orb().create_any();
              MarketDataApp.DataUnitHelper.insert(__result, ___result);
              r.result(__result);
              }
              break;
           case 1: // MarketDataApp.MarketData.getNextData
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
              MarketDataApp.DataUnit ___result;
              try {
                            ___result = this.getNextData();
              }
              catch (MarketDataApp.CorbaSqlException e0) {
                            org.omg.CORBA.Any _except = _orb().create_any();
                            MarketDataApp.CorbaSqlExceptionHelper.insert(_except, e0);
                            r.except(_except);
                            return;
              }
              org.omg.CORBA.Any __result = _orb().create_any();
              MarketDataApp.DataUnitHelper.insert(__result, ___result);
              r.result(__result);
              }
              break;
            default:
              throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
       }
 }
}
