/*
 * File: ./MARKETDATAAPP/MARKETDATA.JAVA
 * From: MARKETDATA.IDL
 * Date: Tue Feb 09 11:31:12 1999
 *   By: idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package MarketDataApp;
public interface MarketData
    extends org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity {
    MarketDataApp.DataUnit getFirstData(String name, String password, int year, int month, int day)
        throws MarketDataApp.LoginException, MarketDataApp.CorbaSqlException;
    MarketDataApp.DataUnit getNextData()
        throws MarketDataApp.CorbaSqlException;
}
