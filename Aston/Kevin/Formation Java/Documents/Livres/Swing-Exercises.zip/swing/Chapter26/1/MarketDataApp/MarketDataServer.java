/*
 * MarketDataServer
 */

package MarketDataApp;

import java.sql.*;
import java.util.*;

import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CORBA.*;

public class MarketDataServer
	extends _MarketDataImplBase
{
	protected Connection m_conn;
	protected Statement  m_stmt;
	protected ResultSet  m_results;

	public MarketDataServer()
	{
		try
		{
			// Load the JDBC-ODBC bridge driver
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

    public DataUnit getFirstData(String name, String password, 
		int year, int month, int day)
        throws MarketDataApp.LoginException, MarketDataApp.CorbaSqlException
	{
		if (!name.equals("CORBA") || !password.equals("Swing"))
			throw new MarketDataApp.LoginException();

		String query = "SELECT data.symbol, symbols.name, "+
			"data.last, data.open, data.change, data.changeproc, "+
			"data.volume FROM DATA INNER JOIN SYMBOLS "+
			"ON DATA.symbol = SYMBOLS.symbol WHERE "+
			"month(data.date1)="+month+" AND day(data.date1)="+day+
			" AND year(data.date1)="+year;

		try
		{
			m_conn = DriverManager.getConnection(
				"jdbc:odbc:Market", "admin", "");

			m_stmt = m_conn.createStatement();
			m_results = m_stmt.executeQuery(query);

			if (m_results.next())
				return new DataUnitImpl(m_results);
			else
			{
				disconnect();
				return null;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new CorbaSqlException(e.toString());
		}
	}

    public DataUnit getNextData()
        throws MarketDataApp.CorbaSqlException
	{
		try
		{
			if (m_results != null && m_results.next())
				return new DataUnitImpl(m_results);
			else
			{
				disconnect();
				return null;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new CorbaSqlException(e.toString());
		}
	}

    protected void disconnect()
	{
		try
		{
			if (m_results != null)
				m_results.close();
			if (m_stmt != null)
				m_stmt.close();
			if (m_conn != null)
				m_conn.close();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		m_results = null;
		m_stmt = null;
		m_conn = null;
	}

	public static void main(String args[])    
	{	
		try
		{
			// create and initialize the ORB	    
			Properties props = new Properties();
			props.put("org.omg.CORBA.ORBInitialPort", "1250");
			ORB orb = ORB.init(args, props); 
			
			// create server and register it with the ORB
			MarketDataServer server = new MarketDataServer();	    
			orb.connect(server); 
			
			// get the root naming context	    
			org.omg.CORBA.Object objRef = 
				orb.resolve_initial_references("NameService");
			NamingContext ncRef = NamingContextHelper.narrow(objRef); 

			// bind the Object Reference in Naming
			NameComponent nc = new NameComponent("MarketData", "");
			NameComponent path[] = {nc};	    
			ncRef.rebind(path, server); 
			
			// wait for invocations from clients
			java.lang.Object sync = new java.lang.Object();
			synchronized (sync) 
			{                
				System.out.println("Waiting for client connection");
				sync.wait();            
			} 
		} 
		catch (Exception e) 
		{	    
			e.printStackTrace(System.out);	
		}    
	}

}
