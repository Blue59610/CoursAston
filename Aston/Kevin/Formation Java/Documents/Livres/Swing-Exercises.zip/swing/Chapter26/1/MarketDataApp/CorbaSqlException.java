/*
 * File: ./MARKETDATAAPP/CORBASQLEXCEPTION.JAVA
 * From: MARKETDATA.IDL
 * Date: Tue Feb 09 11:31:12 1999
 *   By: idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package MarketDataApp;
public final class CorbaSqlException
	extends org.omg.CORBA.UserException implements org.omg.CORBA.portable.IDLEntity {
    //	instance variables
    public String reason;
    //	constructors
    public CorbaSqlException() {
	super();
    }
    public CorbaSqlException(String __reason) {
	super();
	reason = __reason;
    }
}
