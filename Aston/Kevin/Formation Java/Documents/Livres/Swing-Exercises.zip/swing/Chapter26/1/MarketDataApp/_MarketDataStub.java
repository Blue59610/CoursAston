/*
 * File: ./MARKETDATAAPP/_MARKETDATASTUB.JAVA
 * From: MARKETDATA.IDL
 * Date: Tue Feb 09 11:31:12 1999
 *   By: idltojava Java IDL 1.2 Aug 18 1998 16:25:34
 */

package MarketDataApp;
public class _MarketDataStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements MarketDataApp.MarketData {

    public _MarketDataStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:MarketDataApp/MarketData:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::MarketDataApp::MarketData::getFirstData
    public MarketDataApp.DataUnit getFirstData(String name, String password, int year, int month, int day)
        throws MarketDataApp.LoginException, MarketDataApp.CorbaSqlException {
           org.omg.CORBA.Request r = _request("getFirstData");
           r.set_return_type(MarketDataApp.DataUnitHelper.type());
           org.omg.CORBA.Any _name = r.add_in_arg();
           _name.insert_string(name);
           org.omg.CORBA.Any _password = r.add_in_arg();
           _password.insert_string(password);
           org.omg.CORBA.Any _year = r.add_in_arg();
           _year.insert_long(year);
           org.omg.CORBA.Any _month = r.add_in_arg();
           _month.insert_long(month);
           org.omg.CORBA.Any _day = r.add_in_arg();
           _day.insert_long(day);
           r.exceptions().add(MarketDataApp.LoginExceptionHelper.type());
           r.exceptions().add(MarketDataApp.CorbaSqlExceptionHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(MarketDataApp.LoginExceptionHelper.type())) {
                   throw MarketDataApp.LoginExceptionHelper.extract(__userEx.except);
               }
               if (__userEx.except.type().equals(MarketDataApp.CorbaSqlExceptionHelper.type())) {
                   throw MarketDataApp.CorbaSqlExceptionHelper.extract(__userEx.except);
               }
           }
           MarketDataApp.DataUnit __result;
           __result = MarketDataApp.DataUnitHelper.extract(r.return_value());
           return __result;
   }
    //	    Implementation of ::MarketDataApp::MarketData::getNextData
    public MarketDataApp.DataUnit getNextData()
        throws MarketDataApp.CorbaSqlException {
           org.omg.CORBA.Request r = _request("getNextData");
           r.set_return_type(MarketDataApp.DataUnitHelper.type());
           r.exceptions().add(MarketDataApp.CorbaSqlExceptionHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(MarketDataApp.CorbaSqlExceptionHelper.type())) {
                   throw MarketDataApp.CorbaSqlExceptionHelper.extract(__userEx.except);
               }
           }
           MarketDataApp.DataUnit __result;
           __result = MarketDataApp.DataUnitHelper.extract(r.return_value());
           return __result;
   }

};
