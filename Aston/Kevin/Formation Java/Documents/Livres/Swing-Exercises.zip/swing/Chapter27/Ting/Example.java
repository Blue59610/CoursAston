/*
 * Sample program demonstrating multiline tooltips and labels.  Notice that
 * you can use either the system property "line.separator" or "\n" to break up
 * the line.
 *
 * $Revision: 1.11 $ 
 *
 * @author Albert L. Ting
 */

import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.*;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.*;

import jalt.*;

public class Example {
  static JLabel labels[];
  static JFrame frame;
  static JTable table;
  static ExampleTableModel model;
  // used to change the label alignment.  
  static DefaultTableCellRenderer labelRenderer;

  public static void main(String[] args) {
    MultiLineToolTipUI.initialize();
    MultiLineLabelUI.initialize();

    ExampleLabels lablePane = new ExampleLabels();
    JMenuBar menubar;
    JMenu menu;
    JMenuItem menuItem;
    JScrollPane scroller;

    labels = lablePane.getLabels();
    frame = new JFrame();
    menubar = new JMenuBar();
    table = new JTable();
    model = new ExampleTableModel();
    frame.setJMenuBar(menubar);
    scroller = new JScrollPane(table,
			       JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
			       JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    scroller.setColumnHeaderView(table.getTableHeader());

    // we do this only because we want to fool around with the alignment
    labelRenderer = new DefaultTableCellRenderer();
    labelRenderer.setHorizontalAlignment(JLabel.CENTER);
    table.setDefaultRenderer(String.class,labelRenderer);

    table.setRowHeight(32);
    table.setModel(model);

    // make the remaining column headers vertical
    for (int i=1; i<model.getColumnCount(); i++) {
      TableColumn column = table.getColumn(model.getColumnName(i));
      JLabel headerRenderer = (JLabel) column.getHeaderRenderer();
      headerRenderer.putClientProperty(
	MultiLineLabelUI.ORIENTATION_MODE,MultiLineLabelUI.VERTICAL);
      headerRenderer.setVerticalAlignment(JLabel.BOTTOM);
    }

    ActionListener alignmentAction = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
	String command = e.getActionCommand();
	String mode;
	if (command.equals("Block Alignment")) {
	  mode = MultiLineLabelUI.BLOCK;
	} else {
	  mode = MultiLineLabelUI.INDIVIDUAL;
	}
	MultiLineLabelUI.setDefaultAlignmentMode(mode);
	frame.getContentPane().invalidate();
	frame.getContentPane().repaint();
      }
    };
    ActionListener clippedAction = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
	String command = e.getActionCommand();
	String mode;
	if (command.equals("Clip Text")) {
	  mode = MultiLineLabelUI.CLIPPED;
	} else {
	  mode = MultiLineLabelUI.NOT_CLIPPED;
	}
	MultiLineLabelUI.setDefaultClippedMode(mode);
	frame.getContentPane().invalidate();
	frame.getContentPane().repaint();
      }
    };
    ActionListener acceleratorAction = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
	String command = e.getActionCommand();
	String mode;
	if (command.equals("Display Accelerator In ToolTips")) {
	  MultiLineToolTipUI.setDisplayAcceleratorKey(true);
	} else {
	  MultiLineToolTipUI.setDisplayAcceleratorKey(false);
	}
      }
    };
    ActionListener motifAction = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
	try {
	  UIManager.setLookAndFeel(
	    "com.sun.java.swing.plaf.motif.MotifLookAndFeel");
	  SwingUtilities.updateComponentTreeUI(frame);
	} catch (Exception err) {
	  System.out.println("unable to select Motif look: "+err);
	}
      }
    };
    ActionListener metalAction = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
	try {
	  UIManager.setLookAndFeel(
	    "javax.swing.plaf.metal.MetalLookAndFeel");
	  SwingUtilities.updateComponentTreeUI(frame);
	} catch (Exception err) {
	  System.out.println("unable to select Metal look: "+err);
	}
      }
    };

    menu = new JMenu("Menu");
    menubar.add(menu);
    menuItem = new JMenuItem("Block Alignment");
    menuItem.addActionListener(alignmentAction);
    menu.add(menuItem);
    menuItem = new JMenuItem("Individual Alignment");
    menuItem.addActionListener(alignmentAction);
    menu.add(menuItem);

    menu.addSeparator();

    menuItem = new JMenuItem("Clip Text");
    menuItem.addActionListener(clippedAction);
    menu.add(menuItem);
    menuItem = new JMenuItem("Don't Clip Text");
    menuItem.addActionListener(clippedAction);
    menu.add(menuItem);

    menu.addSeparator();

    menuItem = new JMenuItem("Display Accelerator In ToolTips");
    menuItem.addActionListener(acceleratorAction);
    menu.add(menuItem);
    menuItem = new JMenuItem("Don't Display Accelerator");
    menuItem.addActionListener(acceleratorAction);
    menu.add(menuItem);

    menu.addSeparator();

    menuItem = new JMenuItem("Motif L&F");
    menuItem.addActionListener(motifAction);
    menu.add(menuItem);
    menuItem = new JMenuItem("Metal L&F");
    menuItem.addActionListener(metalAction);
    menu.add(menuItem);

    menu.addSeparator();

    menuItem = new JMenuItem("Exit");
    menu.add(menuItem);
    menuItem.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
	System.exit(0);
      }
    });
    menuItem.setToolTipText("Close\nthis\nwindow!");
    menuItem.setAccelerator(
      KeyStroke.getKeyStroke(KeyEvent.VK_Q, ActionEvent.CTRL_MASK));

    frame.getContentPane().add("East",lablePane);
    frame.getContentPane().add("Center",scroller);
    frame.pack();
    frame.setSize(600,400);
    frame.setVisible(true);
  }
}

