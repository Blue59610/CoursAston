/*
 * Sample program demonstrating multiline tooltips and labels.  Notice that
 * you can use either the system property "line.separator" or "\n" to break up
 * the line
 *
 * $Revision: 1.4 $ 
 *
 * @author Albert L. Ting
 */

import java.io.*;
import java.net.*;
import java.util.*;
import java.lang.*;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.*;

import jalt.*;

public class ExampleTableModel extends AbstractTableModel {
  String name[] = {"description\ntext","data\nvalues","boolean\nvalues"};
  Class cl[] = {String.class,String.class,Boolean.class};
  Object table[][] = {
    {"this is line\n1","data\n1",new Boolean(true)},
    {"this is line\n2","data\n2",new Boolean(false)},
    {"this is line\n3","data\n3",new Boolean(true)},
    {"this is line\n4","data\n4",new Boolean(false)},
    {"this is line\n5","data\n5",new Boolean(true)},
    {"this is line\n6","data\n6",new Boolean(false)},
    {"this is line\n7","data\n7",new Boolean(true)},
    {"this is line\n8","data\n8",new Boolean(false)},
    {"this is line\n9","data\n9",new Boolean(true)}};

  public int getColumnCount() { return table[0].length; }
  public int getRowCount() { return table.length;}
  public Object getValueAt(int r, int c) {
    return table[r][c];
  }
  public String getColumnName(int column) {
    return name[column];
  }
  public Class getColumnClass(int c) {
    return cl[c];
  }
  public boolean isCellEditable(int r, int c) { return false; }
  public void setValueAt(Object aValue, int r, int c) { }
}

