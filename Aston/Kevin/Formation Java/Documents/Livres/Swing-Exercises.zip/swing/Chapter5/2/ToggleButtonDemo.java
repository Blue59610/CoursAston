import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class ToggleButtonDemo extends JFrame
{
  public ToggleButtonDemo ()
  {
    super("ToggleButton/ButtonGroup Demo");
    getContentPane().setLayout(new FlowLayout());

    JToggleButton button1 = new JToggleButton("Button 1",true);
    getContentPane().add(button1);
    JToggleButton button2 = new JToggleButton("Button 2",false);
    getContentPane().add(button2);
    JToggleButton button3 = new JToggleButton("Button 3",false);
    getContentPane().add(button3);

    ButtonGroup buttonGroup = new ButtonGroup();
    buttonGroup.add(button1);
    buttonGroup.add(button2);
    buttonGroup.add(button3);

    pack();
    setVisible(true);
  }

  public static void main(String args[])
  {
    new ToggleButtonDemo();
  }
}
