/**
	Split
*/
import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;

public class Split 
	extends    JFrame 
	implements Runnable
{
	protected GasPanel m_left;
	protected GasPanel m_right;

	public Split()
	{
		super("Gas Pressure [Split Pane]");
		setSize(600, 300);
		getContentPane().setLayout(new BorderLayout());
		
		ImageIcon ball1 = new ImageIcon("ball1.gif");
		m_left = new GasPanel(30, ball1.getImage());
		ImageIcon ball2 = new ImageIcon("ball2.gif");
		m_right = new GasPanel(30, ball2.getImage());
		JSplitPane sp = new JSplitPane(
			JSplitPane.HORIZONTAL_SPLIT, m_left, m_right);
		sp.setDividerSize(10);
		sp.setContinuousLayout(true);
		getContentPane().add(sp, BorderLayout.CENTER);

		WindowListener wndCloser = new WindowAdapter()
		{
			public void windowClosing(WindowEvent e) 
			{
				System.exit(0);
			}
		};
		addWindowListener(wndCloser);
		
		setVisible(true);

		new Thread(m_left).start();
		new Thread(m_right).start();
		new Thread(this).start();
	}

	public void run()
	{
		while (true)
		{
			int p1  = (int)m_left.m_px2;
			int pv1 = p1*m_left.getWidth();
			int p2 = (int)m_right.m_px1;
			int pv2 = p2*m_right.getWidth();
			System.out.println("Left: p="+p1+"\tpv="+pv1+
				"\tRight: p="+p2+"\tpv="+pv2);
			m_left.clearCounters();
			m_right.clearCounters();
			
			try 
			{ 
				Thread.sleep(20000); 
			} 
			catch(InterruptedException e) {}
		}
	}

	public static void main(String argv[]) 
	{
		new Split();
	}
}

class GasPanel 
	extends    JPanel 
	implements Runnable
{
	protected Atom[] m_atoms;
	protected Image  m_img;
	protected Rectangle m_rc;

	public double m_px1 = 0;
	public double m_px2 = 0;
	public double m_py1 = 0;
	public double m_py2 = 0;

	public GasPanel(int nAtoms, Image img)
	{
		setBackground(Color.white);
		enableEvents(ComponentEvent.COMPONENT_RESIZED);

		m_img = img;
		m_atoms = new Atom[nAtoms];
		m_rc = new Rectangle(getPreferredSize());
		for (int k=0; k<nAtoms; k++)
		{
			m_atoms[k] = new Atom(this);
		}
	}

	public Dimension getPreferredSize()
	{
		return new Dimension(300, 300);
	}

	public void run()
	{
		while (true)
		{
			for (int k=0; k<m_atoms.length; k++)
				m_atoms[k].move(m_rc);
			repaint();
			
			try 
			{ 
				Thread.sleep(100); 
			} 
			catch(InterruptedException e) {}
		}
	}

	public void paintComponent(Graphics g)
	{
		g.setColor(getBackground());
		g.fillRect(m_rc.x, m_rc.y, m_rc.width, m_rc.height);

		for (int k=0; k<m_atoms.length; k++)
			g.drawImage(m_img, m_atoms[k].getX(), 
				m_atoms[k].getY(), this);
	}

	protected void processComponentEvent(ComponentEvent e)
	{
		if (e.getID() == ComponentEvent.COMPONENT_RESIZED)
		{
			m_rc.setSize(getSize());
			for (int k=0; k<m_atoms.length; k++)
				m_atoms[k].ensureInRect(m_rc);
		}
	}

	public void clearCounters()
	{
		m_px1 = 0;
		m_px2 = 0;
		m_py1 = 0;
		m_py2 = 0;
	}
}

class Atom
{
	protected double m_x;
	protected double m_y;
	protected double m_vx;
	protected double m_vy;

	protected GasPanel m_parent;

	public Atom(GasPanel parent)
	{
		m_parent = parent;
		m_x = parent.m_rc.x + parent.m_rc.width*Math.random();
		m_y = parent.m_rc.y + parent.m_rc.height*Math.random();
		double angle = 2*Math.PI*Math.random();
		m_vx = 10*Math.cos(angle);
		m_vy = 10*Math.sin(angle);
	}

	public void move(Rectangle rc)
	{
		double x = m_x + m_vx;
		double y = m_y + m_vy;
		int x1 = rc.x;
		int x2 = rc.x + rc.width;
		int y1 = rc.y;
		int y2 = rc.y + rc.height;
		for (int bounce = 0; bounce<2; bounce++)
		{
			if (x < x1)
			{
				x += 2*(x1-x);
				m_vx = - m_vx;
				m_parent.m_px1 += 2*Math.abs(m_vx);
			}
			if (x > x2)
			{
				x -= 2*(x-x2);
				m_vx = - m_vx;
				m_parent.m_px2 += 2*Math.abs(m_vx);
			}
			if (y < y1)
			{
				y += 2*(y1-y);
				m_vy = - m_vy;
				m_parent.m_py1 += 2*Math.abs(m_vy);
			}
			if (y > y2)
			{
				y -= 2*(y-y2);
				m_vy = - m_vy;
				m_parent.m_py2 += 2*Math.abs(m_vy);
			}
		}
		m_x = x;
		m_y = y;
	}

	public void ensureInRect(Rectangle rc)
	{
		if (m_x < rc.x)
			m_x = rc.x;
		if (m_x > rc.x + rc.width)
			m_x = rc.x + rc.width;
		if (m_y < rc.y)
			m_y = rc.y;
		if (m_y > rc.y + rc.height)
			m_y = rc.y + rc.height;
	}

	public int getX() { return (int)m_x; }

	public int getY() { return (int)m_y; }
}

