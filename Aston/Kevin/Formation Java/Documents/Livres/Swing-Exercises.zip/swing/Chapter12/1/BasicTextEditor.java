/**
	BasicTextEditor
*/
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

import javax.swing.*;
import javax.swing.event.*;

public class BasicTextEditor 
	extends JFrame 
{

	public static final String FONTS[] = { "Serif", "SansSerif", 
		"Courier" };
	protected Font m_fonts[];

	protected JTextArea m_monitor;
	protected JMenuItem[] m_fontMenus;
	protected JCheckBoxMenuItem m_bold;
	protected JCheckBoxMenuItem m_italic;

	protected JFileChooser m_chooser;

	public BasicTextEditor()
	{
		super("Basic text editor: part I - Menus");
		setSize(450, 350);

		m_fonts = new Font[FONTS.length];
		for (int k=0; k<FONTS.length; k++)
			m_fonts[k] = new Font(FONTS[k], Font.PLAIN, 12);

		m_monitor = new JTextArea();
		JScrollPane ps = new JScrollPane(m_monitor);
		getContentPane().add(ps, BorderLayout.CENTER);

		m_monitor.append("Basic text editor");

		JMenuBar menuBar = createMenuBar();
		setJMenuBar(menuBar);

		m_chooser = new JFileChooser(); 
		m_chooser.setCurrentDirectory(new File("."));

		WindowListener wndCloser = new WindowAdapter()
		{
			public void windowClosing(WindowEvent e) 
			{
				System.exit(0);
			}
		};
		addWindowListener(wndCloser);
		
		updateMonitor();
		setVisible(true);
	}

	protected JMenuBar createMenuBar()
	{
		final JMenuBar menuBar = new JMenuBar();
		
		JMenu mFile = new JMenu("File");
		mFile.setMnemonic('f');

		JMenuItem item = new JMenuItem("New");
		item.setIcon(new ImageIcon("file_new.gif"));
		item.setMnemonic('n');
		ActionListener lst = new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent e)
			{
				m_monitor.setText("");
			}
		};
		item.addActionListener(lst);
		mFile.add(item);

		item = new JMenuItem("Open...");
		item.setIcon(new ImageIcon("file_open.gif"));
		item.setMnemonic('o');
		lst = new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent e)
			{
                                BasicTextEditor.this.repaint();
				if (m_chooser.showOpenDialog(BasicTextEditor.this) != 
					JFileChooser.APPROVE_OPTION)
					return;
                                Thread runner = new Thread() {
                                  public void run() {
				    File fChoosen = m_chooser.getSelectedFile();
				    try
				    {
					FileReader in = new FileReader(fChoosen);
					m_monitor.read(in, null);
					in.close();
				    } 
				    catch (IOException ex) 
				    {
					ex.printStackTrace();
				    }
                                  }
                                };
                                runner.start();
			}
		};
		item.addActionListener(lst);
		mFile.add(item);

		item = new JMenuItem("Save...");
		item.setIcon(new ImageIcon("file_save.gif"));
		item.setMnemonic('s');
		lst = new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent e)
			{
                                BasicTextEditor.this.repaint();
				if (m_chooser.showSaveDialog(BasicTextEditor.this) != 
					JFileChooser.APPROVE_OPTION)
					return;
                                Thread runner = new Thread() {
                                  public void run() {
			 	    File fChoosen = m_chooser.getSelectedFile();
				    try
				    {
					FileWriter out = new 
						FileWriter(fChoosen);
					m_monitor.write(out);
					out.close();
				    } 
				    catch (IOException ex) 
				    {
					ex.printStackTrace();
				    }
                                  }
                                };
                                runner.start();
			}
		};
		item.addActionListener(lst);
		mFile.add(item);

		mFile.addSeparator();

		item = new JMenuItem("Exit");
		item.setMnemonic('x');
		lst = new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent e)
			{
				System.exit(0);
			}
		};
		item.addActionListener(lst);
		mFile.add(item);
		menuBar.add(mFile);

		ActionListener fontListener = new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent e)
			{
				updateMonitor();
			}
		};
		
		JMenu mFont = new JMenu("Font");
		mFont.setMnemonic('o');

		ButtonGroup group = new ButtonGroup();
		m_fontMenus = new JMenuItem[FONTS.length];
		for (int k=0; k<FONTS.length; k++)
		{
			int m = k+1;
			m_fontMenus[k] = new JRadioButtonMenuItem(
				m+" "+FONTS[k]);
			boolean selected = (k == 0);
			m_fontMenus[k].setSelected(selected);
			m_fontMenus[k].setMnemonic('1'+k);
			m_fontMenus[k].setFont(m_fonts[k]);
			m_fontMenus[k].addActionListener(fontListener);
			group.add(m_fontMenus[k]);
			mFont.add(m_fontMenus[k]);
		}
		
		mFont.addSeparator();

		m_bold = new JCheckBoxMenuItem("Bold");
		m_bold.setMnemonic('b');
		Font fn = m_fonts[1].deriveFont(Font.BOLD);
		m_bold.setFont(fn);
		m_bold.setSelected(false);
		m_bold.addActionListener(fontListener);
		mFont.add(m_bold);

		m_italic = new JCheckBoxMenuItem("Italic");
		m_italic.setMnemonic('i');
		fn = m_fonts[1].deriveFont(Font.ITALIC);
		m_italic.setFont(fn);
		m_italic.setSelected(false);
		m_italic.addActionListener(fontListener);
		mFont.add(m_italic);

		menuBar.add(mFont);

		return menuBar;
	}

	protected void updateMonitor()
	{
		int index = -1;
		for (int k=0; k<m_fontMenus.length; k++)
		{
			if (m_fontMenus[k].isSelected())
			{
				index = k;
				break;
			}
		}
		if (index == -1)
			return;

		if (index==2)  // Courier
		{
			m_bold.setSelected(false);
			m_bold.setEnabled(false);
			m_italic.setSelected(false);
			m_italic.setEnabled(false);
		}
		else
		{
			m_bold.setEnabled(true);
			m_italic.setEnabled(true);
		}

		int style = Font.PLAIN;
		if (m_bold.isSelected())
			style |= Font.BOLD;
		if (m_italic.isSelected())
			style |= Font.ITALIC;
		Font fn = m_fonts[index].deriveFont(style);
		m_monitor.setFont(fn);
		m_monitor.repaint();
	}

	public static void main(String argv[]) 
	{
		new BasicTextEditor();
	}
}
