/**
	XmlTree
*/
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import java.net.*;

import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;

import com.sun.xml.tree.*;
import com.sun.xml.parser.*;
import org.w3c.dom.*;

public class XmlTree 
	extends JFrame 
{

	protected JTree  m_tree;
	protected DefaultTreeModel m_model;
	protected JTextField m_location;

	public XmlTree()
	{
		super("XML Tree");
		setSize(400, 300);
		getContentPane().setLayout(new BorderLayout());

		m_location = new JTextField();
		m_location.setText("samples\\book-order.xml");
		ActionListener lst = new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent e)
			{
				readXml(m_location.getText());
			}
		};
		m_location.addActionListener(lst);
		getContentPane().add(m_location, BorderLayout.NORTH);

		DefaultMutableTreeNode top = new DefaultMutableTreeNode(
			"Empty");
		m_model = new DefaultTreeModel(top);
		m_tree = new JTree(m_model);

		m_tree.getSelectionModel().setSelectionMode(
			TreeSelectionModel.SINGLE_TREE_SELECTION);            
		m_tree.setShowsRootHandles(true); 
		m_tree.setEditable(false);

		JScrollPane s = new JScrollPane();
		s.getViewport().add(m_tree);
		getContentPane().add(s, BorderLayout.CENTER);

		WindowListener wndCloser = new WindowAdapter()
		{
			public void windowClosing(WindowEvent e) 
			{
				System.exit(0);
			}
		};
		addWindowListener(wndCloser);
		
		setVisible(true);
	}

	public void readXml(String sUrl)
	{
		setCursor( Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR) );
		try
		{
			URL source;
			try
			{
				File f = new File(sUrl);
				source = f.toURL();
			}
			catch (Exception ex)
			{
				source = new URL(sUrl);
			}

			XmlDocument doc = XmlDocumentBuilder.createXmlDocument(
				source.toString());

			ElementNode root = (ElementNode)doc.getDocumentElement();
			root.normalize();

			DefaultMutableTreeNode top = createTreeNode(root);

			m_model.setRoot(top);
			m_tree.treeDidChange();
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
			JOptionPane.showMessageDialog(this, 
				ex.toString(), "Warning", 
				JOptionPane.WARNING_MESSAGE);
		}
		setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}

	protected DefaultMutableTreeNode createTreeNode(ElementNode root)
	{
		DefaultMutableTreeNode node = new DefaultMutableTreeNode(
			root.getNodeName());
		for (int k=0; k<root.getLength(); k++)
		{
			Node nd = root.item(k);

			if (nd instanceof DataNode)
			{
				DataNode dn = (DataNode)nd;

				String data = dn.getData().trim();
				if (data.equals("\n") || data.equals("\r\n"))
					data = "";
				if (data.length() > 0)
					node.add(new DefaultMutableTreeNode(data));
			}
			else if (nd instanceof ElementNode)
			{
				ElementNode en = (ElementNode)nd;
				node.add(createTreeNode(en));
			}
		}
		return node;
	}

	public static void main(String argv[]) 
	{
		new XmlTree();
	}
}
