/**
	Game2D
*/
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.geom.*;
import java.util.*;

import javax.swing.*;
import javax.swing.border.*;

public class Game2D 
	extends JFrame 
{

	public Game2D()
	{
		super("2D Game");
		getContentPane().setLayout(new BorderLayout());

		PacMan2D field = new PacMan2D(this);
		getContentPane().add(field, BorderLayout.CENTER);

		WindowListener wndCloser = new WindowAdapter()
		{
			public void windowClosing(WindowEvent e) 
			{
				System.exit(0);
			}
		};
		addWindowListener(wndCloser);
		
		pack();
		setResizable(false);
		setVisible(true);
	}

	public static void main(String argv[]) 
	{
		new Game2D();
	}

}

class PacMan2D 
	extends JPanel
{
	static final int N_IMG = 4;
	static final int X_CELL = 20;
	static final int Y_CELL = 20;
	static final int N_STEP = 10;
	static final double STEP = 0.1f;

	protected int m_nx;
	protected int m_ny;
	protected int[][] m_flags;
	protected double m_creatureX = 0;
	protected double m_creatureY = 0;
	protected int m_posX = 0;
	protected int m_posY = 0;
	protected int m_creatureVx = 1;
	protected int m_creatureVy = 0;
	protected int m_creatureDir = 0;
	protected int m_creatureInd = 0;
	protected int m_creatureNewVx = 1;
	protected int m_creatureNewVy = 0;
	protected int m_creatureNewDir = 0;

	protected String[] m_data = {
		"00000000000000000000",		// 0
		"00110000001000000000",		// 1
		"00010000001000000000",		// 2
		"00000000001011111100",		// 3
		"00110000010000111111",		// 4
		"00001000000000000000",		// 5
		"00000100001100011000",		// 6
		"00010000001000000011",		// 7
		"00000000111011110010",		// 8
		"01000100001000010010",		// 9
		"00000000000000000000",		// 10
		"00000010001111100100",		// 11
		"00011010000000000100",		// 12
		"00000000011111000100",		// 13
		"00001111100000000110",		// 14
		"00000000000000000010",		// 15
		"00000000001111000010",		// 16
		"00000000000001111010",		// 17
		"00011100000000011100",		// 18
		"00000111100000000000" };	// 19

	protected Image m_wallImage;
	protected Image m_ballImage;
	protected Image[][] m_creature;
	protected Thread m_runner;
	protected JFrame m_parent;

	public PacMan2D(JFrame parent)
	{
		setBackground(Color.black);
		m_parent = parent;

		AffineTransform[] at = new AffineTransform[3];
		at[0] = new AffineTransform(0, 1, -1, 0, Y_CELL, 0);
		at[1] = new AffineTransform(-1, 0, 0, 1, X_CELL, 0);
		at[2] = new AffineTransform(0, -1, -1, 0, Y_CELL, X_CELL);

		ImageIcon icon = new ImageIcon("wall.gif");
		m_wallImage = icon.getImage();
		icon = new ImageIcon("ball.gif");
		m_ballImage = icon.getImage();
		m_creature = new Image[N_IMG][4];
		for (int k=0; k<N_IMG; k++)
		{
			int kk = k + 1;
			icon = new ImageIcon("creature"+kk+".gif");
			m_creature[k][0] = icon.getImage();

			for (int d=0; d<3; d++)
			{
				BufferedImage bi = new BufferedImage(X_CELL, Y_CELL, 
					BufferedImage.TYPE_INT_RGB);
				Graphics2D g2 = bi.createGraphics();
				g2.drawImage(m_creature[k][0], at[d], this);
				m_creature[k][d+1] = bi;
			}
		}

		m_nx = m_data[0].length();
		m_ny = m_data.length;
		m_flags = new int[m_ny][m_nx];
		for (int i=0; i<m_ny; i++)
		for (int j=0; j<m_nx; j++)
			m_flags[i][j] = (m_data[i].charAt(j)=='0' ? 0 : 1);

		m_runner = new Thread()
		{
			public void run()
			{
				m_flags[m_posY][m_posX] = -1;

				while (!m_parent.isShowing())
					try { sleep(150); } 
					catch (InterruptedException ex) { return; }

				while (true)
				{
					m_creatureVx = m_creatureNewVx;
					m_creatureVy = m_creatureNewVy;
					m_creatureDir = m_creatureNewDir;
					int j = m_posX+m_creatureVx;
					int i = m_posY+m_creatureVy;
					if (j >=0 && j < m_nx && i >= 0 && i < m_ny && 
						m_flags[i][j] != 1)
					{
						for (int k=0; k<N_STEP; k++)
						{
							m_creatureX += STEP*m_creatureVx;
							m_creatureY += STEP*m_creatureVy;
							m_creatureInd++;
							m_creatureInd = m_creatureInd % N_IMG;
							final int x = (int)(m_creatureX*X_CELL);
							final int y = (int)(m_creatureY*Y_CELL);
	                                                Runnable painter = new Runnable() {
                                                          public void run() {
                                                            PacMan2D.this.paintImmediately(x-1, y-1, X_CELL+3, Y_CELL+3);
                                                          }
                                                        };
                                                        try {
                                                          SwingUtilities.invokeAndWait(painter);
                                                        } catch (Exception e) {}
                                                        try { sleep(40); }
                                                        catch (InterruptedException ex) { break; }
						}
						if (m_flags[i][j] == 0)
							m_flags[i][j] = -1;
						m_posX += m_creatureVx;
						m_posY += m_creatureVy;
						m_creatureX = m_posX;
						m_creatureY = m_posY;
					}
					else
						try { sleep(150); } 
						catch (InterruptedException ex) { break; }

				}
			}
		};
		m_runner.start();

		KeyAdapter lst = new KeyAdapter()
		{
			public void keyPressed(KeyEvent e)
			{
				switch (e.getKeyCode())
				{
				case KeyEvent.VK_RIGHT:
					m_creatureNewVx = 1;
					m_creatureNewVy = 0;
					m_creatureNewDir = 0;
					break;
				case KeyEvent.VK_DOWN:
					m_creatureNewVx = 0;
					m_creatureNewVy = 1;
					m_creatureNewDir = 1;
					break;
				case KeyEvent.VK_LEFT:
					m_creatureNewVx = -1;
					m_creatureNewVy = 0;
					m_creatureNewDir = 2;
					break;
				case KeyEvent.VK_UP:
					m_creatureNewVx = 0;
					m_creatureNewVy = -1;
					m_creatureNewDir = 3;
					break;
				}
			}
		};
		parent.addKeyListener(lst);
	}

	public Dimension getPreferredSize()
	{
		return new Dimension(m_nx*X_CELL, m_ny*Y_CELL);
	}

	public Dimension getMaximumSize()
	{
		return getPreferredSize();
	}

	public Dimension getMinimumSize()
	{
		return getPreferredSize();
	}

	public void paintComponent(Graphics g)
	{
		Graphics2D g2 = (Graphics2D) g;
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
			RenderingHints.VALUE_ANTIALIAS_ON);
		g2.setRenderingHint(RenderingHints.KEY_RENDERING,
			RenderingHints.VALUE_RENDER_QUALITY);

		g2.setColor(getBackground());
		g2.fill(g.getClip());

		int x, y;
		for (int i=0; i<m_ny; i++)
		for (int j=0; j<m_nx; j++)
		{
			x = j*X_CELL;
			y = i*Y_CELL;
			if (m_flags[i][j] == 1)
				g2.drawImage(m_wallImage, x, y, this);
			else if (m_flags[i][j] == 0)
				g2.drawImage(m_ballImage, x, y, this);
		}

		x = (int)(m_creatureX*X_CELL);
		y = (int)(m_creatureY*Y_CELL);
		g2.drawImage(m_creature[m_creatureInd][m_creatureDir], x, y, this);
	}

}
