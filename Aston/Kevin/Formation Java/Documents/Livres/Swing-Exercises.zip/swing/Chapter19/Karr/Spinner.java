import java.util.*;
import java.lang.reflect.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.plaf.*;
import javax.swing.plaf.basic.*;

public class Spinner extends JPanel
{
   private int m_orientation = SwingConstants.VERTICAL;
   private BasicArrowButton m_incrementButton;
   private BasicArrowButton m_decrementButton;

   public Spinner() { createComponents(); }

   public Spinner(int orientation)
   {
      m_orientation = orientation;
      createComponents();
   }

   public void setEnabled(boolean enable)
   {
      m_incrementButton.setEnabled(enable);
      m_decrementButton.setEnabled(enable);
   }

   public boolean isEnabled()
   {
      return (m_incrementButton.isEnabled() &&
         m_decrementButton.isEnabled());
   }
   
   protected void createComponents()
   {
      if (m_orientation == SwingConstants.VERTICAL)
      {
         setLayout(new GridLayout(2, 1));
         m_incrementButton = new BasicArrowButton(
            SwingConstants.NORTH);
         m_decrementButton = new BasicArrowButton(
            SwingConstants.SOUTH);
         add(m_incrementButton);
         add(m_decrementButton);
      }
      else if (m_orientation == SwingConstants.HORIZONTAL)
      {
         setLayout(new GridLayout(1, 2));
         m_incrementButton = new BasicArrowButton(
            SwingConstants.EAST);
         m_decrementButton = new BasicArrowButton(
            SwingConstants.WEST);
         add(m_decrementButton);
         add(m_incrementButton);
      }
   }

   public JButton getIncrementButton() { 
      return (m_incrementButton); }
   public JButton getDecrementButton() { 
      return (m_decrementButton); }

   public static void main(String[] args)
   {
      JFrame frame = new JFrame();
      JPanel panel = (JPanel) frame.getContentPane();
      panel.setLayout(new BorderLayout());
      JTextField  field = new JTextField(20);
      Spinner spinner = new Spinner();

      panel.add(field, "Center");
      panel.add(spinner, "East");

      Dimension dim = frame.getToolkit().getScreenSize();
      frame.setLocation(dim.width/2 - frame.getWidth()/2,
         dim.height/2 - frame.getHeight()/2);
      frame.pack();
      frame.show();
   }
}
