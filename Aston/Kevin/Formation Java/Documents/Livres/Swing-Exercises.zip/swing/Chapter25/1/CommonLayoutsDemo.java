/**
	Help1
*/
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import java.net.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.help.*;	// NEW

public class CommonLayoutsDemo extends JFrame 
{
    protected HelpSet m_hs;	// NEW
    protected HelpBroker m_hb;
	static final String HELPSETNAME = "Help/Layout.hs";

	public CommonLayoutsDemo()
	{
		super("Common Layout Managers [Help]");
		setSize(500, 380);

		createHelp();	// NEW
		InternalFrameAdapter activator = new InternalFrameAdapter()
		{
			public void internalFrameActivated(InternalFrameEvent e)
			{
				JInternalFrame fr = (JInternalFrame)e.getSource();
				Component c = fr.getContentPane().getComponent(0);
				if (c != null)
					c.requestFocus();
			}
		};

		JDesktopPane desktop = new JDesktopPane();
		getContentPane().add(desktop);

		JInternalFrame fr1 = new JInternalFrame("FlowLayout", true, true);
		fr1.setBounds(10, 10, 150, 150);
		Container c = fr1.getContentPane();
		c.setLayout(new FlowLayout());
		c.add(new JButton("1"));
		c.add(new JButton("2"));
		c.add(new JButton("3"));
		c.add(new JButton("4"));
		desktop.add(fr1, 0);
		CSH.setHelpIDString(fr1,"FlowLayout");	// NEW
		fr1.addInternalFrameListener(activator);

		JInternalFrame fr2 = new JInternalFrame("GridLayout", true, true);
		fr2.setBounds(170, 10, 150, 150);
		c = fr2.getContentPane();
		c.setLayout(new GridLayout(2, 2));
		c.add(new JButton("1"));
		c.add(new JButton("2"));
		c.add(new JButton("3"));
		c.add(new JButton("4"));
		desktop.add(fr2, 0);
		CSH.setHelpIDString(fr2,"GridLayout");	// NEW
		fr2.addInternalFrameListener(activator);

		JInternalFrame fr3 = new JInternalFrame("BorderLayout", true, true);
		fr3.setBounds(330, 10, 150, 150);
		c = fr3.getContentPane();
		c.setLayout(new BorderLayout());
		c.add(new JButton("1"), BorderLayout.NORTH);
		c.add(new JButton("2"), BorderLayout.EAST);
		c.add(new JButton("3"), BorderLayout.SOUTH);
		c.add(new JButton("4"), BorderLayout.WEST);
		desktop.add(fr3, 0);
		CSH.setHelpIDString(fr3,"BorderLayout");	// NEW
		fr3.addInternalFrameListener(activator);

		JInternalFrame fr4 = new JInternalFrame("BoxLayout - X", true, true);
		fr4.setBounds(10, 170, 250, 120);
		c = fr4.getContentPane();
		c.setLayout(new BoxLayout(c, BoxLayout.X_AXIS));
		c.add(new JButton("1"));
		c.add(Box.createHorizontalStrut(12));
		c.add(new JButton("2"));
		c.add(Box.createGlue());
		c.add(new JButton("3"));
		c.add(Box.createHorizontalGlue());
		c.add(new JButton("4"));
		desktop.add(fr4, 0);
		CSH.setHelpIDString(fr4,"BoxLayout");	// NEW
		fr4.addInternalFrameListener(activator);

		JInternalFrame fr5 = new JInternalFrame("BoxLayout - Y", true, true);
		fr5.setBounds(330, 170, 150, 180);
		c = fr5.getContentPane();
		c.setLayout(new BoxLayout(c, BoxLayout.Y_AXIS));
		c.add(new JButton("1"));
		c.add(Box.createVerticalStrut(10));
		c.add(new JButton("2"));
		c.add(Box.createGlue());
		c.add(new JButton("3"));
		c.add(Box.createVerticalGlue());
		c.add(new JButton("4"));
		desktop.add(fr5, 0);
		CSH.setHelpIDString(fr5,"BoxLayout");	// NEW
		fr5.addInternalFrameListener(activator);
		
		try 
		{ 
			fr1.setSelected(true); 
		} 
		catch (java.beans.PropertyVetoException ex) {}

		WindowListener wndCloser = new WindowAdapter()
		{
			public void windowClosing(WindowEvent e) 
			{
				System.exit(0);
			}
		};
		addWindowListener(wndCloser);
		
		setVisible(true);
	}

	public static void main(String argv[]) 
	{
		new CommonLayoutsDemo();
	}

// NEW
	protected void createHelp()
	{
		ClassLoader loader = this.getClass().getClassLoader();
		URL url;
		try 
		{
			url = HelpSet.findHelpSet(loader, HELPSETNAME);
			m_hs = new HelpSet(loader, url);

			m_hb = m_hs.createHelpBroker();
			m_hb.enableHelpKey(getRootPane(), "top", m_hs);
		} 
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
	}
}
