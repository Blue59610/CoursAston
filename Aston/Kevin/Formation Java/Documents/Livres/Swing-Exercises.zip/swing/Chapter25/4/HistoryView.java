/**
	HistoryView
*/
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.net.*;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import javax.help.*;
import javax.help.event.*;

public class HistoryView 
	extends TOCView
	implements HelpModelListener
{
	protected DefaultMutableTreeNode m_topNode;
	protected JTree m_tree;
	protected DefaultTreeModel m_model;
	protected TreePath m_zeroPath;

	public HistoryView(HelpSet hs, String name, String label,
		Hashtable params) 
	{
		super(hs, name, label, hs.getLocale(), params);
	}

	public HistoryView(HelpSet hs, String name, String label,
		Locale locale, Hashtable params)
	{
		super(hs, name, label, locale, params);
	}

	public Component createNavigator(HelpModel model) 
	{
		JHelpNavigator navigator = new JHelpTOCNavigator(this, model);
		navigator.getUI().setIcon(new ImageIcon("History.gif"));
		return navigator;
	}

	public static DefaultMutableTreeNode parse(URL url, HelpSet hs,
		Locale locale, TreeItemFactory factory) 
	{
		return new DefaultMutableTreeNode("History");
	}

	public void setNavigator(JHelpNavigator jhn)
	{
		jhn.getModel().addHelpModelListener(this);

		try
		{
			Container c = jhn;
			while (!(c instanceof JTree))
				c = (Container)(c.getComponent(0));
			m_tree = (JTree)c;
			TOCItem top = new TOCItem();
			top.setName("History");
			m_topNode = new DefaultMutableTreeNode(top);
			m_model = new DefaultTreeModel(m_topNode);
			m_tree.setModel(m_model);

			m_zeroPath = new TreePath(new Object[] { m_topNode });
		}
		catch (Exception ex) 
		{
			ex.printStackTrace();
			System.err.println(ex.toString());
		}
	}

	public void idChanged(HelpModelEvent e)
	{
		// To avoid conflict with java.util.Map
		javax.help.Map.ID id = e.getID();
		if (m_topNode != null)
		{
			TOCItem item = new TOCItem(id, null, null);
			item.setName(id.id);
			for (int k=0; k<m_topNode.getChildCount(); k++)
			{
				DefaultMutableTreeNode child = 
					(DefaultMutableTreeNode)m_topNode.getChildAt(k);
				TOCItem childItem = (TOCItem)child.getUserObject();
				if (childItem.getID().equals(id))
					m_topNode.remove(child);
			}
			DefaultMutableTreeNode node = new DefaultMutableTreeNode(item);
			m_topNode.insert(node, 0);
			m_model.reload(m_topNode);
			m_tree.expandPath(m_zeroPath);
		}
	}
}
