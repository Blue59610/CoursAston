package mdi;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class MDIPane 
extends JLayeredPane
implements ComponentListener
{
  public MDIPane() {
    addComponentListener(this);
    setOpaque(true);

    // default background color
    setBackground(new Color(244,232,152));
  }

  public void componentHidden(ComponentEvent e) {}
  public void componentMoved(ComponentEvent e) {}
  public void componentShown(ComponentEvent e) {}
  public void componentResized(ComponentEvent e) { lineup(); }
  public void lineup() {
    int frameHeight, frameWidth, currentX, currentY, lheight, lwidth;
    lwidth = getWidth();
    lheight = getHeight();
    currentX = 0;
    currentY = lheight;
    Component[] components = getComponents();
    for (int i=components.length-1; i>-1; i--) {
      if (components[i] instanceof InnerFrame) {
        InnerFrame tempFrame = (InnerFrame) components[i];
        frameHeight = tempFrame.getHeight();
        frameWidth = tempFrame.getWidth();
        if (tempFrame.isMaximized()) {
          tempFrame.setBounds(0,0,getWidth(),getHeight());
          tempFrame.validate(); 
          tempFrame.repaint(); 
        }
        else if (tempFrame.isIconified()) {
          if (currentX+frameWidth > lwidth) {
            currentX = 0;
            currentY -= frameHeight;
          }
          tempFrame.setLocation(currentX, currentY-frameHeight);
          currentX += frameWidth;
        }
      }
    }
  }
}
