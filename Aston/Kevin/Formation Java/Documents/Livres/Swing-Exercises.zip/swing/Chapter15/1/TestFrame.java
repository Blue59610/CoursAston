import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TestFrame extends JFrame 
{
  public TestFrame() 
  {
    super("JLayeredPane Demo");
    setSize(256,256);
  
    JPanel content = new JPanel();
    content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
    content.setOpaque(false);
    
    JLabel label1 = new JLabel("Username:");
    label1.setForeground(Color.white);
    content.add(label1);

    JTextField field = new JTextField(15);
    content.add(field);

    JLabel label2 = new JLabel("Password:");
    label2.setForeground(Color.white);
    content.add(label2);

    JPasswordField fieldPass = new JPasswordField(15);
    content.add(fieldPass);

    getContentPane().setLayout(new FlowLayout());
    getContentPane().add(content);
    ((JPanel)getContentPane()).setOpaque(false);
    
    ImageIcon earth = new ImageIcon("earth.jpg");
    JLabel backlabel = new JLabel(earth);
    getLayeredPane().add(backlabel, new Integer(Integer.MIN_VALUE));
    backlabel.setBounds(0,0,earth.getIconWidth(),
      earth.getIconHeight());

    WindowListener l = new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    };
    addWindowListener(l);

    setVisible(true);
  }
 
  public static void main(String[] args)
  {
    new TestFrame();
  }
}