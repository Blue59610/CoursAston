import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import mdi.*;

public class LayeredPaneDemo extends JFrame
{
  public LayeredPaneDemo() 
  {
    super("Custom MDI: Part IV");
    setSize(570,400);
    getContentPane().setBackground(new Color(244,232,152));

    setLayeredPane(new MDIPane());
   
    ImageIcon ii = new ImageIcon("earth.jpg");
    InnerFrame[] frames = new InnerFrame[5];
    for(int i=0; i<5; i++) 
    {
      frames[i] = new InnerFrame("InnerFrame " + i);
      frames[i].setBounds(50+i*20, 50+i*20, 200, 200);
      frames[i].getContentPane().add(
        new JScrollPane(new JLabel(ii)));
      getLayeredPane().add(frames[i]);
    }

    WindowListener l = new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    };

    Dimension dim = getToolkit().getScreenSize();
    setLocation(dim.width/2-getWidth()/2, 
      dim.height/2-getHeight()/2);

    ImageIcon image = new ImageIcon("spiral.gif");
    setIconImage(image.getImage());
    addWindowListener(l);
    setVisible(true);
  }

  public static void main(String[] args) 
  {
    new LayeredPaneDemo();
  }
}