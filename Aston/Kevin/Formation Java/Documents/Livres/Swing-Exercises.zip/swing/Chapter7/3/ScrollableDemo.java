import java.awt.*;
import javax.swing.*;

public class ScrollableDemo
extends JFrame
{
  public ScrollableDemo() {
    super("JScrollPane Demo");
    ImageIcon ii = new ImageIcon("earth.jpg");
    JScrollPane jsp = new JScrollPane(new MyScrollableLabel(ii));
    getContentPane().add(jsp);
    setSize(300,250);
    setVisible(true);
  }

  public static void main(String[] args) { 
    new ScrollableDemo();
  }
}

class MyScrollableLabel
extends JLabel
implements Scrollable 
{
  public MyScrollableLabel(ImageIcon i){
    super(i);
  }

  public Dimension getPreferredScrollableViewportSize() {
    return getPreferredSize();
  }
  
  public int getScrollableBlockIncrement(Rectangle r, 
    int orietation, int direction) {
      return 10;
  }

  public boolean getScrollableTracksViewportHeight() {
    return false;
  }

  public boolean getScrollableTracksViewportWidth() {
    return false;
  }

  public int getScrollableUnitIncrement(Rectangle r, 
    int orientation, int direction) {
      return 10;
  }
}
