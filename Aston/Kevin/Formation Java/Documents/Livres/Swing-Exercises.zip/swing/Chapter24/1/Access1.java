/**
	Access1
*/
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import java.net.*;

import java.lang.reflect.*;

import sun.net.ftp.*;
import sun.net.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;

import dl.*;

public class Access1 
	extends JFrame 
{
	public static int BUFFER_SIZE = 10240;

	protected JTextField m_txtUser;
	protected JPasswordField m_txtPassword;
	protected JTextField m_txtURL;
	protected JTextField m_txtFile;
	protected JTextArea  m_monitor;
	protected JProgressBar m_progress;
	protected JButton m_btPut;
	protected JButton m_btGet;
	protected JButton m_btFile;
	protected JButton m_btClose;
	protected JFileChooser m_chooser;

	protected FtpClient m_client;
	protected String m_sLocalFile;
	protected String m_sHostFile;

	public Access1()
	{
		super("FTP Client [Accessible]");
		getContentPane().setLayout(new BorderLayout());
		
		JPanel p = new JPanel();
		p.setLayout(new DialogLayout2(10, 5));
		p.setBorder(new EmptyBorder(5, 5, 5, 5));

// NEW
		JLabel lbl = new JLabel("User name:");
		lbl.setDisplayedMnemonic('n');
		p.add(lbl);
		m_txtUser = new JTextField("anonymous");
		m_txtUser.setToolTipText("User name");
		p.add(m_txtUser);
		lbl.setLabelFor(m_txtUser);

		lbl = new JLabel("Password:");
		lbl.setDisplayedMnemonic('p');
		p.add(lbl);
		m_txtPassword = new JPasswordField();
		m_txtPassword.setToolTipText("Password");
		p.add(m_txtPassword);
		lbl.setLabelFor(m_txtPassword);

		lbl = new JLabel("URL:");
		lbl.setDisplayedMnemonic('u');
		p.add(lbl);
		m_txtURL = new JTextField();
		m_txtURL.setToolTipText("URL");
		p.add(m_txtURL);
		lbl.setLabelFor(m_txtURL);

		lbl = new JLabel("File:");
		lbl.setDisplayedMnemonic('l');
		p.add(lbl);
		m_txtFile = new JTextField();
		m_txtFile.setToolTipText("File");
		p.add(m_txtFile);
		lbl.setLabelFor(m_txtFile);

		p.add(new DialogSeparator("Connection Monitor"));
		m_monitor = new JTextArea(5, 20);
		m_monitor.setEditable(false);
		JScrollPane ps = new JScrollPane(m_monitor);
		p.add(ps);

		m_progress = new JProgressBar();
		m_progress.setStringPainted(true);
		m_progress.setBorder(new BevelBorder(BevelBorder.LOWERED, 
			Color.white, Color.gray));
		m_progress.setMinimum(0);
		JPanel p1 = new JPanel(new BorderLayout());
		p1.add(m_progress, BorderLayout.CENTER);
		p.add(p1);

		p.add(new DialogSeparator());
		m_btPut = new JButton("Put");
		m_btPut.setToolTipText("Upload file");	// NEW
		ActionListener lst = new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent e)
			{
				Thread uploader = new Thread()
				{
					public void run()
					{
						if (connect())
							putFile();
						disconnect();
					}
				};
				uploader.start();
			}
		};
		m_btPut.addActionListener(lst);
		m_btPut.setMnemonic('p');
		p.add(m_btPut);

		m_btGet = new JButton("Get");
		m_btGet.setToolTipText("Download file");	// NEW
		lst = new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent e)
			{
				Thread downloader = new Thread()
				{
					public void run()
					{
						if (connect())
							getFile();
						disconnect();
					}
				};
				downloader.start();
			}
		};
		m_btGet.addActionListener(lst);
		m_btGet.setMnemonic('g');
		p.add(m_btGet);

		m_btFile = new JButton("File");
		m_btFile.setToolTipText("Select file");	// NEW
		lst = new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent e)
			{
				if (m_chooser.showSaveDialog(Access1.this) != 
					JFileChooser.APPROVE_OPTION)
					return;
				File f = m_chooser.getSelectedFile();
				m_txtFile.setText(f.getPath());
			}
		};
		m_btFile.addActionListener(lst);
		m_btFile.setMnemonic('f');
		p.add(m_btFile);

		m_btClose = new JButton("Close");
		m_btClose.setToolTipText("Quit application");	// NEW
		lst = new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent e)
			{
				if (m_client != null)
					disconnect();
				else
					System.exit(0);
			}
		};
		m_btClose.addActionListener(lst);
		m_btClose.setDefaultCapable(true);
		p.add(m_btClose);

		getContentPane().add(p, BorderLayout.CENTER);

		m_chooser = new JFileChooser();
		m_chooser.setCurrentDirectory(new File("."));
		m_chooser.setApproveButtonToolTipText(
			"Select file for upload/download");

		WindowListener wndCloser = new WindowAdapter()
		{
			public void windowClosing(WindowEvent e) 
			{
				disconnect();
				System.exit(0);
			}
		};
		addWindowListener(wndCloser);
		
		pack();
		setVisible(true);
	}

	protected boolean connect()
	{
		m_monitor.setText("");
		m_btPut.setEnabled(false);
		m_btGet.setEnabled(false);
		m_btFile.setEnabled(false);
		m_btClose.setText("Cancel");
		setCursor(Cursor.getPredefinedCursor(
			Cursor.WAIT_CURSOR));

		String user = m_txtUser.getText();
		if (user.length()==0)
		{
			message("Please enter user name");
			return false;
		}
		String password = new String(m_txtPassword.getPassword());
		String sUrl = m_txtURL.getText();
		if (sUrl.length()==0)
		{
			message("Please enter URL");
			return false;
		}
		m_sLocalFile = m_txtFile.getText();

		// Parse URL
		int index = sUrl.indexOf("//");
		if (index >= 0)
			sUrl = sUrl.substring(index+2);
		
		index = sUrl.indexOf("/");
		String host = sUrl.substring(0, index);
		sUrl = sUrl.substring(index+1);
		
		String sDir = "";
		index = sUrl.lastIndexOf("/");
		if (index >= 0)
		{
			sDir = sUrl.substring(0, index);
			sUrl = sUrl.substring(index+1);
		}
		m_sHostFile = sUrl;
		
		try
		{
			message("Connecting to host "+host);
			m_client = new FtpClient(host);

			m_client.login(user, password);
			message("User "+user+" login OK");
			message(m_client.welcomeMsg);

			m_client.cd(sDir);
			message("Directory: "+sDir);
			m_client.binary();
			
			return true;
		}
		catch (Exception ex)
		{
			message("Error: "+ex.toString());
			return false;
		}
	}

	protected void disconnect()
	{
		if (m_client != null)
		{
			try { m_client.closeServer(); }
			catch (IOException ex) {}
			m_client = null;
		}

		m_progress.setValue(0);
		m_btPut.setEnabled(true);
		m_btGet.setEnabled(true);
		m_btFile.setEnabled(true);
		m_btClose.setText("Close");
		setCursor(Cursor.getPredefinedCursor(
			Cursor.DEFAULT_CURSOR));
	}

	protected void getFile()
	{
		if (m_sLocalFile.length()==0)
		{
			m_sLocalFile = m_sHostFile;
			m_txtFile.setText(m_sLocalFile);
		}

		byte[] buffer = new byte[BUFFER_SIZE];
		try
		{

			int size = getFileSize(m_client, m_sHostFile);
			if (size > 0)
			{
				message("File "+m_sHostFile+": "+size+" bytes");
				m_progress.setMaximum(size);
			}
			else
				message("File "+m_sHostFile+": size unknown");

			FileOutputStream out = new 
				FileOutputStream(m_sLocalFile);
			InputStream in = m_client.get(m_sHostFile);
			int counter = 0;

			while(true)
			{
				int bytes = in.read(buffer);
				if (bytes < 0)
					break;
				out.write(buffer, 0, bytes);
				counter += bytes;

				if (size > 0)
				{
					m_progress.setValue(counter);
					int proc = (int)Math.round(m_progress.
						getPercentComplete()*100);
					m_progress.setString(proc+" %");
				}
				else
				{
					int kb = counter/1024;
					m_progress.setString(kb+" KB");
				}
			}

			out.close();
			in.close();
		}
		catch (Exception ex)
		{
			message("Error: "+ex.toString());
		}
	}

	protected void putFile()
	{
		if (m_sLocalFile.length()==0)
		{
			message("Please enter file name");
		}

		byte[] buffer = new byte[BUFFER_SIZE];
		try
		{
			File f = new File(m_sLocalFile);
			int size = (int)f.length();
			message("File "+m_sLocalFile+": "+size+" bytes");
			m_progress.setMaximum(size);

			FileInputStream in = new 
				FileInputStream(m_sLocalFile);
			OutputStream out = m_client.put(m_sHostFile);
			int counter = 0;

			while(true)
			{
				int bytes = in.read(buffer);
				if (bytes < 0)
					break;
				out.write(buffer, 0, bytes);
				counter += bytes;

				m_progress.setValue(counter);
				int proc = (int)Math.round(m_progress.
					getPercentComplete()*100);
				m_progress.setString(proc+" %");
			}

			out.close();
			in.close();
		}
		catch (Exception ex)
		{
			message("Error: "+ex.toString());
		}
	}

	protected void message(String str)
	{
		if (str != null)
		{
			m_monitor.append(str+'\n');
			m_monitor.paintImmediately(0, 0, m_monitor.getWidth(), 
				m_monitor.getHeight());
		}
	}

	public static void main(String argv[]) 
	{
		new Access1();
	}

	public static int getFileSize(FtpClient client, String fileName)
		throws IOException
	{
		TelnetInputStream lst = client.list();
		String str = "";
		fileName = fileName.toLowerCase();
		while(true)
		{
			int c = lst.read();
			char ch = (char)c;
			if (c < 0 || ch == '\n')
			{
				str = str.toLowerCase();
				if (str.indexOf(fileName) >= 0)
				{
					StringTokenizer tk = new StringTokenizer(str);
					int index = 0;
					while(tk.hasMoreTokens())
					{
						String token = tk.nextToken();
						if (index == 4)
							try
							{
								return Integer.parseInt(token);
							}
							catch (NumberFormatException ex)
							{
								return -1;
							}
						index++;
					}
				}
				str = "";
			}
			if (c <= 0)
				break;
			str += ch;
		}
		return -1;
	}
}

