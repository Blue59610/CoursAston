/**
	Access2
*/
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.sql.*;

import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.text.rtf.*;
import javax.accessibility.*;	// NEW

public class Access2 
	extends JDialog
{
	protected int m_option = JOptionPane.CLOSED_OPTION;
	protected OpenList m_lstFontName;
	protected OpenList m_lstFontSize;
	protected MutableAttributeSet m_attributes;
	protected JCheckBox m_chkBold;
	protected JCheckBox m_chkItalic;
	protected JCheckBox m_chkUnderline;
	
	protected JCheckBox m_chkStrikethrough;
	protected JCheckBox m_chkSubscript;
	protected JCheckBox m_chkSuperscript;
	
	protected JComboBox m_cbColor;
	protected JLabel m_preview;

	public static String[] m_fontNames;
	public static String[] m_fontSizes;

	public Access2(JFrame owner)
	{
		super(owner, "Font Dialog [Accessible]", false);
		getContentPane().setLayout(new BoxLayout(getContentPane(), 
			BoxLayout.Y_AXIS));

		JPanel p = new JPanel(new GridLayout(1, 2, 10, 2));
		p.setBorder(new TitledBorder(new EtchedBorder(), "Font"));
		m_lstFontName = new OpenList(m_fontNames, "Name:");
		p.add(m_lstFontName);
		m_lstFontName.setDisplayedMnemonic('n');	// NEW
		m_lstFontName.setToolTipText("Font name");

		m_lstFontSize = new OpenList(m_fontSizes, "Size:");
		p.add(m_lstFontSize);
		m_lstFontSize.setDisplayedMnemonic('s');	// NEW
		m_lstFontSize.setToolTipText("Font size");
		getContentPane().add(p);

		p = new JPanel(new GridLayout(2, 3, 10, 5));
		p.setBorder(new TitledBorder(new EtchedBorder(), "Effects"));
		m_chkBold = new JCheckBox("Bold");
		m_chkBold.setMnemonic('b');			// NEW
		m_chkBold.setToolTipText("Bold font");
		p.add(m_chkBold);
		m_chkItalic = new JCheckBox("Italic");
		m_chkItalic.setMnemonic('i');		// NEW
		m_chkItalic.setToolTipText("Italic font");
		p.add(m_chkItalic);
		m_chkUnderline = new JCheckBox("Underline");
		m_chkUnderline.setMnemonic('u');	// NEW
		m_chkUnderline.setToolTipText("Underline font");
		p.add(m_chkUnderline);
		m_chkStrikethrough = new JCheckBox("Strikethrough");
		m_chkStrikethrough.setMnemonic('r');	// NEW
		m_chkStrikethrough.setToolTipText("Strikethrough font");
		p.add(m_chkStrikethrough);
		m_chkSubscript = new JCheckBox("Subscript");
		m_chkSubscript.setMnemonic('t');	// NEW
		m_chkSubscript.setToolTipText("Subscript font");
		p.add(m_chkSubscript);
		m_chkSuperscript = new JCheckBox("Superscript");
		m_chkSuperscript.setMnemonic('p');	// NEW
		m_chkSuperscript.setToolTipText("Superscript font");
		p.add(m_chkSuperscript);
		getContentPane().add(p);

		getContentPane().add(Box.createVerticalStrut(5));
		p = new JPanel();
		p.setLayout(new BoxLayout(p, BoxLayout.X_AXIS));
		p.add(Box.createHorizontalStrut(10));
		JLabel lbl = new JLabel("Color:");	// NEW
		lbl.setDisplayedMnemonic('c');	// NEW
		p.add(lbl);
		p.add(Box.createHorizontalStrut(20));
		m_cbColor = new JComboBox();
		lbl.setLabelFor(m_cbColor);			// NEW
		m_cbColor.setToolTipText("Font color");
		ToolTipManager.sharedInstance().registerComponent(m_cbColor);
		int[] values = new int[] { 0, 128, 192, 255 };
		for (int r=0; r<values.length; r++)
		for (int g=0; g<values.length; g++)
		for (int b=0; b<values.length; b++)
		{
			Color c = new Color(values[r], values[g], values[b]);
			m_cbColor.addItem(c);
		}
		m_cbColor.setRenderer(new ColorComboRenderer());
		p.add(m_cbColor);
		p.add(Box.createHorizontalStrut(10));
		getContentPane().add(p);

		p = new JPanel(new BorderLayout());
		p.setBorder(new TitledBorder(new EtchedBorder(), "Preview"));
		m_preview = new JLabel("Preview Font", JLabel.CENTER);
		m_preview.setBackground(Color.white);
		m_preview.setForeground(Color.black);
		m_preview.setOpaque(true);
		m_preview.setBorder(new LineBorder(Color.black));
		m_preview.setPreferredSize(new Dimension(120, 40));
		p.add(m_preview, BorderLayout.CENTER);
		getContentPane().add(p);

		p = new JPanel(new FlowLayout());
		JPanel p1 = new JPanel(new GridLayout(1, 2, 10, 2));
		JButton btOK = new JButton("OK");
		btOK.setToolTipText("Save and exit");	// NEW
		getRootPane().setDefaultButton(btOK);
		ActionListener lst = new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent e)
			{
				m_option = JOptionPane.OK_OPTION;
				dispose();
			}
		};
		btOK.addActionListener(lst);
		p1.add(btOK);

		JButton btCancel = new JButton("Cancel");
		btCancel.setToolTipText("Exit without save");	// NEW
		lst = new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent e)
			{
				m_option = JOptionPane.CANCEL_OPTION;
				dispose();
			}
		};
		btCancel.addActionListener(lst);
		p1.add(btCancel);
		p.add(p1);
		getContentPane().add(p);

		pack();
		setResizable(false);
		Dimension d1 = getSize();
		Dimension d2 = owner.getSize();
		int x = Math.max((d2.width-d1.width)/2, 0);
		int y = Math.max((d2.height-d1.height)/2, 0);
		setBounds(x, y, d1.width, d1.height);

		ListSelectionListener lsel = new ListSelectionListener()
		{
			public void valueChanged(ListSelectionEvent e)
			{
				updatePreview();
			}
		};
		m_lstFontName.addListSelectionListener(lsel);
		m_lstFontSize.addListSelectionListener(lsel);

		lst = new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent e)
			{
				updatePreview();
			}
		};
		m_chkBold.addActionListener(lst);
		m_chkItalic.addActionListener(lst);
		m_cbColor.addActionListener(lst);
	}

	public void setAttributes(AttributeSet a)
	{
		m_attributes = new SimpleAttributeSet(a);
		String name = StyleConstants.getFontFamily(a);
		m_lstFontName.setSelected(name);
		int size = StyleConstants.getFontSize(a);
		m_lstFontSize.setSelectedInt(size);
		m_chkBold.setSelected(StyleConstants.isBold(a));
		m_chkItalic.setSelected(StyleConstants.isItalic(a));
		m_chkUnderline.setSelected(StyleConstants.isUnderline(a));
		m_chkStrikethrough.setSelected(StyleConstants.isStrikeThrough(a));
		m_chkSubscript.setSelected(StyleConstants.isSubscript(a));
		m_chkSuperscript.setSelected(StyleConstants.isSuperscript(a));
		m_cbColor.setSelectedItem(StyleConstants.getForeground(a));
		updatePreview();
	}

	public AttributeSet getAttributes()
	{
		if (m_attributes == null)
			return null;
		StyleConstants.setFontFamily(m_attributes, 
			m_lstFontName.getSelected());
		StyleConstants.setFontSize(m_attributes, 
			m_lstFontSize.getSelectedInt());
		StyleConstants.setBold(m_attributes, 
			m_chkBold.isSelected());
		StyleConstants.setItalic(m_attributes, 
			m_chkItalic.isSelected());
		StyleConstants.setUnderline(m_attributes, 
			m_chkUnderline.isSelected());
		StyleConstants.setStrikeThrough(m_attributes, 
			m_chkStrikethrough.isSelected());
		StyleConstants.setSubscript(m_attributes, 
			m_chkSubscript.isSelected());
		StyleConstants.setSuperscript(m_attributes, 
			m_chkSuperscript.isSelected());
		StyleConstants.setForeground(m_attributes, 
			(Color)m_cbColor.getSelectedItem());
		return m_attributes;
	}

	public int getOption()
	{
		return m_option;
	}

	protected void updatePreview()
	{
		String name = m_lstFontName.getSelected();
		int size = m_lstFontSize.getSelectedInt();
		if (size <= 0)
			return;
		int style = Font.PLAIN;
		if (m_chkBold.isSelected())
			style |= Font.BOLD;
		if (m_chkItalic.isSelected())
			style |= Font.ITALIC;

		Font fn = new Font(name, style, size);
		m_preview.setFont(fn);

		Color c = (Color)m_cbColor.getSelectedItem();
		m_preview.setForeground(c);
		m_preview.repaint();
	}

	public static void main(String argv[]) 
	{
		GraphicsEnvironment ge = GraphicsEnvironment.
			getLocalGraphicsEnvironment();
		m_fontNames = ge.getAvailableFontFamilyNames();
		m_fontSizes = new String[] {"8", "9", "10", "11", "12", "14",
			"16", "18", "20", "22", "24", "26", "28", "36", "48", "72"};

		Access2 dlg = new Access2(new JFrame());
		SimpleAttributeSet a = new SimpleAttributeSet();
		StyleConstants.setFontFamily(a, "Monospaced");
		StyleConstants.setFontSize(a, 12);
		dlg.setAttributes(a);
		dlg.show();
	}
}

class OpenList
	extends JPanel
	implements ListSelectionListener, ActionListener
{
	protected JLabel m_title;
	protected JTextField m_text;
	protected JList m_list;
	protected JScrollPane m_scroll;

	public OpenList(String[] data, String title)
	{
		setLayout(null);
		m_title = new OpelListLabel(title, JLabel.LEFT);
		add(m_title);
		m_text = new OpelListText();
		m_text.addActionListener(this);
		m_title.setLabelFor(m_text);	// NEW
		add(m_text);
		m_list = new OpelListList(data);
		m_list.setVisibleRowCount(4);
		m_list.addListSelectionListener(this);
		m_scroll = new JScrollPane(m_list);
		add(m_scroll);
	}

	public OpenList(String title, int numCols)
	{
		setLayout(null);
		m_title = new OpelListLabel(title, JLabel.LEFT);
		add(m_title);
		m_text = new OpelListText(numCols);
		m_text.addActionListener(this);
		m_title.setLabelFor(m_text);	// NEW
		add(m_text);
		m_list = new OpelListList();
		m_list.setVisibleRowCount(4);
		m_list.addListSelectionListener(this);
		m_scroll = new JScrollPane(m_list);
		add(m_scroll);
	}

// NEW	
	public void setToolTipText(String text)
	{
		super.setToolTipText(text);
		m_title.setToolTipText(text);
		m_text.setToolTipText(text);
		m_list.setToolTipText(text);
	}

	public void setDisplayedMnemonic(char ch)
	{
		m_title.setDisplayedMnemonic(ch);
	}

	public void setSelected(String sel)
	{
		m_list.setSelectedValue(sel, true);
		m_text.setText(sel);
	}

	public String getSelected()
	{
		return m_text.getText();
	}

	public void setSelectedInt(int value)
	{
		setSelected(Integer.toString(value));
	}

	public int getSelectedInt()
	{
		try 
		{ 
			return Integer.parseInt(getSelected());
		}
		catch (NumberFormatException ex) { return -1; }
	}

	public void valueChanged(ListSelectionEvent e)
	{
		Object obj = m_list.getSelectedValue();
		if (obj != null)
			m_text.setText(obj.toString());
	}

	public void actionPerformed(ActionEvent e)
	{
		ListModel model = m_list.getModel();
		String key = m_text.getText().toLowerCase();
		for (int k=0; k<model.getSize(); k++)
		{
			String data = (String)model.getElementAt(k);
			if (data.toLowerCase().startsWith(key))
			{
				m_list.setSelectedValue(data, true);
				break;
			}
		}
	}

	public void addListSelectionListener(ListSelectionListener lst)
	{
		m_list.addListSelectionListener(lst);
	}

	public Dimension getPreferredSize()
	{
		Insets ins = getInsets();
		Dimension d1 = m_title.getPreferredSize();
		Dimension d2 = m_text.getPreferredSize();
		Dimension d3 = m_scroll.getPreferredSize();
		int w = Math.max(Math.max(d1.width, d2.width), d3.width);
		int h = d1.height + d2.height + d3.height;
		return new Dimension(w+ins.left+ins.right, 
			h+ins.top+ins.bottom);
	}

	public Dimension getMaximumSize()
	{
		Insets ins = getInsets();
		Dimension d1 = m_title.getMaximumSize();
		Dimension d2 = m_text.getMaximumSize();
		Dimension d3 = m_scroll.getMaximumSize();
		int w = Math.max(Math.max(d1.width, d2.width), d3.width);
		int h = d1.height + d2.height + d3.height;
		return new Dimension(w+ins.left+ins.right, 
			h+ins.top+ins.bottom);
	}

	public Dimension getMinimumSize()
	{
		Insets ins = getInsets();
		Dimension d1 = m_title.getMinimumSize();
		Dimension d2 = m_text.getMinimumSize();
		Dimension d3 = m_scroll.getMinimumSize();
		int w = Math.max(Math.max(d1.width, d2.width), d3.width);
		int h = d1.height + d2.height + d3.height;
		return new Dimension(w+ins.left+ins.right, 
			h+ins.top+ins.bottom);
	}

	public void doLayout()
	{
		Insets ins = getInsets();
		Dimension d = getSize();
		int x = ins.left;
		int y = ins.top;
		int w = d.width-ins.left-ins.right;
		int h = d.height-ins.top-ins.bottom;

		Dimension d1 = m_title.getPreferredSize();
		m_title.setBounds(x, y, w, d1.height);
		y += d1.height;
		Dimension d2 = m_text.getPreferredSize();
		m_text.setBounds(x, y, w, d2.height);
		y += d2.height;
		m_scroll.setBounds(x, y, w, h-y);
	}

	public void appendResultSet(ResultSet results, int index, 
		boolean toTitleCase)
	{
		m_text.setText("");
		DefaultListModel model = new DefaultListModel();
		try
		{
			while (results.next())
			{
				String str = results.getString(index);
				if (toTitleCase)
					str = Utils.titleCase(str); 
				model.addElement(str);
			}
		}
		catch (SQLException ex)
		{
			System.err.println("appendResultSet: "+ex.toString());
		}
		m_list.setModel(model);
		if (model.getSize() > 0)
			m_list.setSelectedIndex(0);
	}

	class OpelListLabel
		extends JLabel
	{
		public OpelListLabel(String text, int alignment)
		{
			super(text, alignment);
		}

		public AccessibleContext getAccessibleContext()
		{
			return OpenList.this.getAccessibleContext();
		}
	}

	class OpelListText
		extends JTextField
	{
		public OpelListText() {}

		public OpelListText(int numCols)
		{
			super(numCols);
		}

		public AccessibleContext getAccessibleContext()
		{
			return OpenList.this.getAccessibleContext();
		}
	}

	class OpelListList
		extends JList
	{
		public OpelListList() {}

		public OpelListList(String[] data)
		{
			super(data);
		}

		public AccessibleContext getAccessibleContext()
		{
			return OpenList.this.getAccessibleContext();
		}
	}

// NEW
	// Accessibility Support

	public AccessibleContext getAccessibleContext() 
	{
		if (accessibleContext == null)
			accessibleContext = new AccessibleOpenList();
		return accessibleContext;
	}

	protected class AccessibleOpenList extends AccessibleJComponent 
	{

		public String getAccessibleName() 
		{
			System.out.println("getAccessibleName: "+accessibleName);
			if (accessibleName != null)
				return accessibleName;
			return m_title.getText();
		}

		public AccessibleRole getAccessibleRole() 
		{
			return AccessibleRole.LIST;
		}
	}
}


class ColorComboRenderer 
	extends    JPanel 
	implements ListCellRenderer
{
	protected Color m_c = Color.black;

	public ColorComboRenderer()
	{
		super();
		setBorder(new CompoundBorder(
			new MatteBorder(2, 10, 2, 10, Color.white),
			new LineBorder(Color.black)));
	}

	public Component getListCellRendererComponent(JList list,
		Object obj, int row, boolean sel,
		boolean hasFocus)
	{
		if (obj instanceof Color)
			m_c = (Color)obj;
		return this;
	}
    
	public void paint(Graphics g) 
	{
		setBackground(m_c);
		super.paint(g);
    }
}

class Utils
{
	public static String titleCase(String source)
	{
		return Character.toUpperCase(source.charAt(0)) + 
			source.substring(1);
	}
}
