/**
	MalachiteLF
*/

package Malachite;

import java.awt.*;

import javax.swing.*;
import javax.swing.plaf.*;
import javax.swing.plaf.basic.*;

public class MalachiteLF 
	extends    BasicLookAndFeel 
	implements java.io.Serializable
{

	public String getID()
	{
		return "Malachite";
	}

	public String getName()
	{
		return "Malachite Look and Feel";
	}

	public String getDescription()
	{
		return "Sample L&F from Swing";
	}

	public boolean isNativeLookAndFeel()
	{
		return false;
	}

	public boolean isSupportedLookAndFeel()
	{
		return true;
	}

	protected void initClassDefaults(UIDefaults table)
	{
		super.initClassDefaults(table);
		
		putDefault(table, "ButtonUI");
		putDefault(table, "CheckBoxUI");
		putDefault(table, "RadioButtonUI");
	}

	protected void putDefault(UIDefaults table, String uiKey)
	{
		try 
		{
			String className = "Malachite.Malachite"+uiKey;
			Class buttonClass = Class.forName(className);
			table.put(uiKey, className);
			table.put(className, buttonClass);
		}
		catch (Exception ex) 
		{
			ex.printStackTrace();
		}

	}

	protected void initComponentDefaults(UIDefaults table)
	{
		super.initComponentDefaults(table);

		ColorUIResource commonBackground = 
			new ColorUIResource(152, 208, 128);
		ColorUIResource commonForeground = 
			new ColorUIResource(0, 0, 0);
		ColorUIResource buttonBackground = 
			new ColorUIResource(4, 108, 2);
		ColorUIResource buttonForeground = 
			new ColorUIResource(236, 236, 0);
		ColorUIResource menuBackground = 
			new ColorUIResource(128, 192, 128);

		ColorUIResource activeForeground = 
			new ColorUIResource(0, 128, 0);
		ColorUIResource focusBorder = 
			new ColorUIResource(255, 255, 255);

		BorderUIResource borderRaised = new 
			BorderUIResource(new MalachiteBorder(
			MalachiteBorder.RAISED));
		BorderUIResource borderLowered = new 
			BorderUIResource(new MalachiteBorder(
			MalachiteBorder.LOWERED));

		FontUIResource commonFont = new 
			FontUIResource("Arial", Font.BOLD, 12 );

		Icon ubox = new ImageIcon("Malachite/ubox.gif");
		Icon ubull = new ImageIcon("Malachite/ubull.gif");

		Icon cbox = new ImageIcon("Malachite/cbox.gif");
		Icon pcbox = new ImageIcon("Malachite/p_cbox.gif");
		Icon pubox = new ImageIcon("Malachite/p_ubox.gif");

		Icon cbull = new ImageIcon("Malachite/cbull.gif");
		Icon pcbull = new ImageIcon("Malachite/p_cbull.gif");
		Icon pubull = new ImageIcon("Malachite/p_ubull.gif");
		
		Object[] defaults =
		{
			"Button.font", commonFont,
			"Button.background", buttonBackground,
			"Button.foreground", buttonForeground,
			"Button.border", borderRaised,
			"Button.margin", new InsetsUIResource(8, 8, 8, 8),
			"Button.textIconGap", new Integer(4),
			"Button.textShiftOffset", new Integer(2),
			"Button.focusBorder", focusBorder,
			"Button.borderPressed", borderLowered,
			"Button.activeForeground", new 
				ColorUIResource(255, 255, 255),
			"Button.pressedBackground", new 
				ColorUIResource(0, 96, 0),

			"CheckBox.font", commonFont,
			"CheckBox.background", commonBackground,
			"CheckBox.foreground", commonForeground,
			"CheckBox.icon", new IconUIResource(ubox),
			"CheckBox.focusBorder", focusBorder,
			"CheckBox.activeForeground", activeForeground,
			"CheckBox.iconPressed", new IconUIResource(pubox),
			"CheckBox.iconChecked", new IconUIResource(cbox),
			"CheckBox.iconPressedChecked", new IconUIResource(pcbox),
			"CheckBox.textIconGap", new Integer(4),
			
			"MenuBar.font", commonFont,
			"MenuBar.background", menuBackground,
			"MenuBar.foreground", commonForeground,
			
			"Menu.font", commonFont,
			"Menu.background", menuBackground,
			"Menu.foreground", commonForeground,
			"Menu.selectionBackground", buttonBackground,
			"Menu.selectionForeground", buttonForeground,

			"MenuItem.font", commonFont,
			"MenuItem.background", menuBackground,
			"MenuItem.foreground", commonForeground,
			"MenuItem.selectionBackground", buttonBackground,
			"MenuItem.selectionForeground", buttonForeground,
			"MenuItem.margin", new InsetsUIResource(2, 2, 2, 2),

			"Panel.background", commonBackground,
			"Panel.foreground", commonForeground,

			"RadioButton.font", commonFont,
			"RadioButton.background", commonBackground,
			"RadioButton.foreground", commonForeground,
			"RadioButton.icon", new IconUIResource(ubull),
			"RadioButton.focusBorder", focusBorder,
			"RadioButton.activeForeground", activeForeground,
			"RadioButton.iconPressed", new IconUIResource(pubull),
			"RadioButton.iconChecked", new IconUIResource(cbull),
			"RadioButton.iconPressedChecked", new IconUIResource(pcbull),
			"RadioButton.textIconGap", new Integer(4),

			"TextArea.margin", new InsetsUIResource(8, 8, 8, 8),
			"TextArea.border", borderLowered
		};

		table.putDefaults( defaults );
	}
}

