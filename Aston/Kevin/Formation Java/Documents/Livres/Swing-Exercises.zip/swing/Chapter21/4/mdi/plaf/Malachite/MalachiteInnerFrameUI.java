
package mdi.plaf.Malachite;

import java.awt.*;
import java.util.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.*;

import mdi.*;
import Malachite.*;

public class MalachiteInnerFrameUI 
	extends mdi.plaf.InnerFrameUI 
{
	private static MalachiteInnerFrameUI frameUI;

	public static ComponentUI createUI(JComponent c) 
	{
		if(frameUI == null)
			frameUI = new MalachiteInnerFrameUI();
		try
		{
			frameUI.installDefaults();

			InnerFrame frame = (InnerFrame)c;
			frame.setTitleBarBackground(DEFAULT_TITLE_BAR_BG_COLOR);
			frame.setSelectedTitleBarBackground(
				DEFAULT_SELECTED_TITLE_BAR_BG_COLOR);
			frame.setTitleBarForeground(DEFAULT_TITLE_BAR_FG_COLOR);
			frame.setSelectedTitleBarForeground(
				DEFAULT_SELECTED_TITLE_BAR_FG_COLOR);
			frame.setTitleBarFont(DEFAULT_TITLE_BAR_FONT);
			frame.setBorder(DEFAULT_INNER_FRAME_BORDER);
			frame.setFrameIcon(DEFAULT_FRAME_ICON);
			if (frame.isShowing())
				frame.repaint();
		}
		catch (Exception ex)
		{
			System.err.println(ex);
			ex.printStackTrace();
		}

		return frameUI;
	}

	protected void installDefaults()
	{
		DEFAULT_TITLE_BAR_BG_COLOR = new ColorUIResource(108,190,116);
		DEFAULT_TITLE_BAR_FG_COLOR = new ColorUIResource(Color.gray);
		DEFAULT_SELECTED_TITLE_BAR_BG_COLOR = 
			new ColorUIResource(0,128,0);
		DEFAULT_SELECTED_TITLE_BAR_FG_COLOR = 
			new ColorUIResource(Color.white);
		DEFAULT_TITLE_BAR_FONT = new FontUIResource(
			"Dialog", Font.BOLD, 12);
		Border fb1 = new MalachiteBorder();
		Border fb2 = new MatteBorder(4, 4, 4, 4, new ImageIcon(
			"mdi/plaf/Malachite/body.gif"));
		DEFAULT_INNER_FRAME_BORDER = new BorderUIResource(
			new CompoundBorder(fb1, fb2));
		DEFAULT_FRAME_ICON = new IconUIResource(new ImageIcon(
			"mdi/plaf/Malachite/icon.gif"));
	}
}
