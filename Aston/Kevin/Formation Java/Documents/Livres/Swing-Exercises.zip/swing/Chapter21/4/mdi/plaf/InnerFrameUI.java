
package mdi.plaf;

import java.awt.*;
import java.util.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.*;

import mdi.*;
import mdi.plaf.Malachite.*;

public class InnerFrameUI 
	extends javax.swing.plaf.PanelUI 
{
	private static InnerFrameUI frameUI;

	protected static Color DEFAULT_TITLE_BAR_BG_COLOR;
	protected static Color DEFAULT_SELECTED_TITLE_BAR_BG_COLOR;
	protected static Color DEFAULT_TITLE_BAR_FG_COLOR;
	protected static Color DEFAULT_SELECTED_TITLE_BAR_FG_COLOR;
	protected static Font  DEFAULT_TITLE_BAR_FONT;
	protected static Border DEFAULT_INNER_FRAME_BORDER;
	protected static Icon  DEFAULT_FRAME_ICON;

	private static Hashtable m_ownDefaults = new Hashtable();
	static
	{
		m_ownDefaults.put("InternalFrame.inactiveTitleBackground",
			new ColorUIResource(108,190,116));
		m_ownDefaults.put("InternalFrame.inactiveTitleForeground",
			new ColorUIResource(Color.black));
		m_ownDefaults.put("InternalFrame.activeTitleBackground",
			new ColorUIResource(91,182,249));
		m_ownDefaults.put("InternalFrame.activeTitleForeground",
			new ColorUIResource(Color.black));
		m_ownDefaults.put("InternalFrame.titleFont",
			new FontUIResource("Dialog", Font.BOLD, 12));
		m_ownDefaults.put("InternalFrame.border",
			new BorderUIResource(new MatteBorder(4, 4, 4, 4, Color.blue)));
		m_ownDefaults.put("InternalFrame.icon",
			new IconUIResource(new ImageIcon("mdi/default.gif")));
	}

	public static ComponentUI createUI(JComponent c) 
	{
		LookAndFeel currentLF = UIManager.getLookAndFeel();	// NEW
		if (currentLF != null && currentLF.getID().equals("Malachite"))
			return mdi.plaf.Malachite.MalachiteInnerFrameUI.createUI(c);

		if(frameUI == null)
			frameUI = new InnerFrameUI();
		try
		{
			frameUI.installDefaults();

			InnerFrame frame = (InnerFrame)c;
			frame.setTitleBarBackground(DEFAULT_TITLE_BAR_BG_COLOR);
			frame.setSelectedTitleBarBackground(
				DEFAULT_SELECTED_TITLE_BAR_BG_COLOR);
			frame.setTitleBarForeground(DEFAULT_TITLE_BAR_FG_COLOR);
			frame.setSelectedTitleBarForeground(
				DEFAULT_SELECTED_TITLE_BAR_FG_COLOR);
			frame.setTitleBarFont(DEFAULT_TITLE_BAR_FONT);
			frame.setBorder(DEFAULT_INNER_FRAME_BORDER);
			frame.setFrameIcon(DEFAULT_FRAME_ICON);
			if (frame.isShowing())
				frame.repaint();
		}
		catch (Exception ex)
		{
			System.err.println(ex);
			ex.printStackTrace();
		}

		return frameUI;
	}

	public void installUI(JComponent c) 
	{
		InnerFrame frame = (InnerFrame)c;
		super.installUI(frame);
	}

	public void uninstallUI(JComponent c) 
	{
		super.uninstallUI(c);
	}

	protected void installDefaults()
	{
		DEFAULT_TITLE_BAR_BG_COLOR = (Color)findDefaultResource(
			"InternalFrame.inactiveTitleBackground");
		DEFAULT_TITLE_BAR_FG_COLOR = (Color)findDefaultResource(
			"InternalFrame.inactiveTitleForeground");
		DEFAULT_SELECTED_TITLE_BAR_BG_COLOR = (Color)findDefaultResource(
			"InternalFrame.activeTitleBackground");
		DEFAULT_SELECTED_TITLE_BAR_FG_COLOR = (Color)findDefaultResource(
			"InternalFrame.activeTitleForeground");
		DEFAULT_TITLE_BAR_FONT = (Font)findDefaultResource(
			"InternalFrame.titleFont");
		DEFAULT_INNER_FRAME_BORDER = (Border)findDefaultResource(
			"InternalFrame.border");
		DEFAULT_FRAME_ICON = (Icon)findDefaultResource(
			"InternalFrame.icon");
	}

	protected Object findDefaultResource(String id)
	{
		Object obj = null;
		try
		{
			UIDefaults uiDef = UIManager.getDefaults();
			obj = uiDef.get(id);
		}
		catch (Exception ex)
		{
			System.err.println(ex);
		}
		if (obj == null)
			obj = m_ownDefaults.get(id);
		return obj;
	}

	public void paint(Graphics g, JComponent c) 
	{
		super.paint(g, c);
		if (c.getBorder() != null)
			c.getBorder().paintBorder(
				c, g, 0, 0, c.getWidth(), c.getHeight());
	}

	public Color getTitleBarBkColor() 
	{
		return DEFAULT_TITLE_BAR_BG_COLOR;
	}

	public Color getSelectedTitleBarBkColor() 
	{
		return DEFAULT_SELECTED_TITLE_BAR_BG_COLOR;
	}

	public Color getTitleBarFgColor() 
	{
		return DEFAULT_TITLE_BAR_FG_COLOR;
	}

	public Color getSelectedTitleBarFgColor() 
	{
		return DEFAULT_SELECTED_TITLE_BAR_FG_COLOR;
	}

	public Font getTitleBarFont() 
	{
		return DEFAULT_TITLE_BAR_FONT;
	}

	public Border getInnerFrameBorder() 
	{
		return DEFAULT_INNER_FRAME_BORDER;
	}

}
