/**
	MdiContainer
*/
import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;

import mdi.*;

public class MdiContainer 
	extends    JFrame 
{
	protected ImageIcon m_icon;
	protected Hashtable m_lfs;

	public MdiContainer()
	{
		super("Custom MDI: Look & Feel");

		setSize(570,400);
                setContentPane(new JDesktopPane());

		m_icon = new ImageIcon("earth.jpg");
		JMenuBar menuBar = createMenuBar();
		setJMenuBar(menuBar);

		WindowListener wndCloser = new WindowAdapter()
		{
			public void windowClosing(WindowEvent e) 
			{
				System.exit(0);
			}
		};
		addWindowListener(wndCloser);
		
		setVisible(true);
	}

	protected JMenuBar createMenuBar()
	{
		JMenuBar menuBar = new JMenuBar();
		
		JMenu mFile = new JMenu("File");
		mFile.setMnemonic('f');

		JMenuItem mItem = new JMenuItem("New InnerFrame");
		mItem.setMnemonic('i');
		ActionListener lst = new ActionListener() 
		{ 
			int m_counter = 0;
			
			public void actionPerformed(ActionEvent e)
			{
				m_counter++;
				InnerFrame frame = new InnerFrame("InnerFrame " + 
					m_counter);
				int i = m_counter % 5;
				frame.setBounds(20+i*20, 20+i*20, 200, 200);
				frame.getContentPane().add(
					new JScrollPane(new JLabel(m_icon)));
				getContentPane().add(frame);
				frame.toFront();
			}
		};
		mItem.addActionListener(lst);
		mFile.add(mItem);

		mItem = new JMenuItem("New JInternalFrame");
		mItem.setMnemonic('j');
		lst = new ActionListener() 
		{ 
			int m_counter = 0;
			
			public void actionPerformed(ActionEvent e)
			{
				m_counter++;
				JInternalFrame frame = new JInternalFrame(
					"JInternalFrame " + m_counter);
				frame.setClosable(true);
				frame.setMaximizable(true);
				frame.setIconifiable(true);
				frame.setResizable(true);

				int i = m_counter % 5;
				frame.setBounds(50+i*20, 50+i*20, 200, 200);
				frame.getContentPane().add(
					new JScrollPane(new JLabel(m_icon)));
				getContentPane().add(frame);
				frame.toFront();
			}
		};
		mItem.addActionListener(lst);
		mFile.add(mItem);
		mFile.addSeparator();

		mItem = new JMenuItem("Exit");
		mItem.setMnemonic('x');
		lst = new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent e)
			{
				System.exit(0);
			}
		};
		mItem.addActionListener(lst);
		mFile.add(mItem);
		menuBar.add(mFile);

		lst = new ActionListener() 
		{ 
			public void actionPerformed(ActionEvent e)
			{
				String str = e.getActionCommand();
				Object obj = m_lfs.get(str);
				if (obj != null)
					try
					{
						String className = (String)obj;
						Class lnfClass = Class.forName(className);
						UIManager.setLookAndFeel(
							(LookAndFeel)(lnfClass.newInstance()));
						SwingUtilities.updateComponentTreeUI(
							MdiContainer.this);
					}
					catch (Exception ex) 
					{
						ex.printStackTrace();
						System.err.println(ex.toString());
					}
			}
		};

		m_lfs = new Hashtable();
		UIManager.LookAndFeelInfo lfs[] =
			UIManager.getInstalledLookAndFeels();
		JMenu mLF = new JMenu("Look&Feel");
		mLF.setMnemonic('l');
		for (int k = 0; k < lfs.length; k++ )
		{
			String name = lfs[k].getName();
			JMenuItem lf = new JMenuItem(name);
			m_lfs.put(name, lfs[k].getClassName());
			lf.addActionListener(lst);
			mLF.add(lf);
		}
		menuBar.add(mLF);

		return menuBar;
	}

	public static void main(String argv[]) 
	{
		new MdiContainer();
	}
}
